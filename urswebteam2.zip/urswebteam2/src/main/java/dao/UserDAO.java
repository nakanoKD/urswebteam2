package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.User;

/**
 * 会員情報の処理をまとめたクラス
 */
public class UserDAO {
	//DB情報をフィールド変数に定義
	private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
	private static String URL = "jdbc:mariadb://localhost/sport_order_db";
	private static String USER = "root";
	private static String PASSWD = "root123";

	/**
	 * 情報を元にDB接続を行うメソッド
	 */
	private static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	/**
	 * ユーザー情報を格納するuser_infoテーブルから全ユーザー情報を取得するメソッド
	 */
	public ArrayList<User> selectAll() {
		Connection con = null;
		Statement smt = null;
		ArrayList<User> userList = new ArrayList<User>();

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT * FROM user_info ORDER BY user_id";
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				User user = new User();
				user.setUserId(rs.getInt("user_id"));
				user.setLoginId(rs.getInt("login_id"));
				user.setEmail(rs.getString("email"));
				user.setLastname(rs.getString("lastname"));
				user.setLastnameRuby(rs.getString("lastname_ruby"));
				user.setFirstname(rs.getString("firstname"));
				user.setFirstnameRuby(rs.getString("firstname_ruby"));
				user.setSex(rs.getString("sex"));
				user.setPostalCode(rs.getString("postal_code"));
				user.setPrefecture(rs.getString("prefecture"));
				user.setCity(rs.getString("city"));
				user.setDeleteFlg(rs.getString("delete_flg"));
				user.setRegistrationDate(rs.getString("registration_date"));
				user.setUpdateDate(rs.getString("update_date"));
				user.setDeleteDate(rs.getString("delete_date "));
				user.setMemberShipFlg(rs.getString("membership_flg "));
				userList.add(user);
			}

		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return userList;
	}

	/**
	 * ユーザーを会員登録するメソッド
	 */
	public void insert(User user) {
		Connection con = null;
		Statement smt = null;

		try {
			con = getConnection();
			smt = con.createStatement();
			//SQL文の発行
			String sql = "INSERT INTO user_info(login_id,email,lastname,"
					+ "lastname_ruby,firstname,firstname_ruby,sex,postal_code,"
					+ "prefecture,city,delete_flg,registration_date,update_date,membership_flg) "
					+ "VALUES(NULL," +
					user.getLoginId() + ",'" +
					user.getEmail() + "','" +
					user.getLastname() + "','" +
					user.getLastnameRuby() + "','" +
					user.getFirstname() + "','" +
					user.getFirstnameRuby() + "','" +
					user.getSex() + "','" +
					user.getPostalCode() + "','" +
					user.getPrefecture() + "','" +
					user.getCity() +
					"',' 0 ',' now() ',' now() ',' 1 '";
			smt.executeUpdate(sql);

		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//クローズ処理
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	/**
	 * 会員が退会するメソッド
	 */
	public void delete(int userId) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			//SQL文の発行
			String sql = "DELETE FROM user_info WHERE user_id =" + userId;
			smt.executeUpdate(sql);

		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//クローズ処理
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	/**
	 * 会員情報を更新するメソッド
	 */
	public void update(User user) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			//SQL文の発行
			String sql = "UPDATE user_info(email,lastname,lastname_ruby,firstname,firstname_ruby,"
							+ "sex,postal_code,prefecture,city,update_date) SET"
							+ "email = '" + user.getEmail() + "',"
							+ "lastname = '" + user.getLastname() + "',"
							+ "lastname_ruby = '" + user.getLastnameRuby() + "',"
							+ "firstname = '" + user.getFirstname() + "',"
							+ "firstname_ruby = '" + user.getFirstnameRuby() + "',"
							+ "sex = '" + user.getSex() + "',"
							+ "postal_code = '" + user.getPostalCode() + "',"
							+ "prefecture = '" + user.getPrefecture() + "',"
							+ "city = '" + user.getCity() + "',"
							+ "update_date = ' now() '"
							+ "WHERE user_id =" + user.getUserId();		
			smt.executeUpdate(sql);

		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//クローズ処理
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}
	
	//ログインIDでユーザーを検索するメソッド
	public User selectByLoginId(int loginId) {
		Connection con = null;
		Statement smt = null;

		// return用Userオブジェクト生成
		User user = new User();

		try {

			// SQL文
			String sql = "SELECT * FROM user_info WHERE login_id =" + loginId + ";";

			// オブジェクト生成
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 結果セットからデータ取得
			while (rs.next()) {
				user.setUserId(rs.getInt("user_id"));
				user.setLoginId(rs.getInt("login_id"));
				user.setEmail(rs.getString("email"));
				user.setLastname(rs.getString("lastname"));
				user.setLastnameRuby(rs.getString("lastname_ruby"));
				user.setFirstname(rs.getString("firstname"));
				user.setFirstnameRuby(rs.getString("firstname_ruby"));
				user.setSex(rs.getString("sex"));
				user.setPostalCode(rs.getString("postal_code"));
				user.setPrefecture(rs.getString("prefecture"));
				user.setCity(rs.getString("city"));
				user.setDeleteFlg(rs.getString("delete_flg"));
				user.setRegistrationDate(rs.getString("registration_date"));
				user.setUpdateDate(rs.getString("update_date"));
				user.setDeleteDate(rs.getString("delete_date"));
				user.setMemberShipFlg(rs.getString("membership_flg"));
			}

		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//リソース開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		//呼び出し元にUserオブジェクトを返す
		return user;
	}
	
	// ユーザーIDでユーザーを検索するメソッド
	public User selectByUserId(int userId) {
		Connection con = null;
		Statement smt = null;

		//return用Userオブジェクト生成
		User user = new User();

		try {

			// SQL文
			String sql = "SELECT * FROM user_info WHERE user_id =" + userId;

			// オブジェクト生成
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 結果セットからデータ取得
			while(rs.next()) {
			user.setUserId(rs.getInt("user_id"));
			user.setLoginId(rs.getInt("login_id"));
			user.setEmail(rs.getString("email"));
			user.setLastname(rs.getString("lastname"));
			user.setLastnameRuby(rs.getString("lastname_ruby"));
			user.setFirstname(rs.getString("firstname"));
			user.setFirstnameRuby(rs.getString("firstname_ruby"));
			user.setSex(rs.getString("sex"));
			user.setPostalCode(rs.getString("postal_code"));
			user.setPrefecture(rs.getString("prefecture"));
			user.setCity(rs.getString("city"));
			user.setDeleteFlg(rs.getString("delete_flg"));
			user.setRegistrationDate(rs.getString("registration_date"));
			user.setUpdateDate(rs.getString("update_date"));
			user.setDeleteDate(rs.getString("delete_date"));
			user.setMemberShipFlg(rs.getString("membership_flg"));
			}
		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//リソース開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		//呼び出し元にUserオブジェクトを返す
		return user;
	}
}
