package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bean.Login;

public class LoginDAO {
	//データベース接続情報定義
		private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
		private static String URL = "jdbc:mariadb://localhost/sport_order_db";
		private static String USER = "root";
		private static String PASS = "root123";

		//データベースに接続するインスタンスメソッドgetConnection
		private static Connection getConnection() {
			try {
				Class.forName(RDB_DRIVE);
				Connection con = DriverManager.getConnection(URL, USER, PASS);
				return con;
			} catch (Exception e) {
				throw new IllegalStateException(e);
			}
		}
		
		//DBから指定ユーザーとパスワードの条件に合う情報を取得するメソッド
		public Login selectByLoginName(String loginName, String password) {
			Connection con = null;
			Statement smt = null;

			//return用Userオブジェクト生成
			Login loginObj = new Login();

			try {

				//SQL文
				String sql = "SELECT * FROM login_info WHERE login_name ='" + loginName
						+ "' AND password='" + password + "';";

				//オブジェクト生成
				con = getConnection();
				smt = con.createStatement();

				//SQL文発行
				ResultSet rs = smt.executeQuery(sql);

				//結果セットから書籍データを取り出し、Userオブジェクトに格納
				while (rs.next()) {
					loginObj.setLoginId(rs.getInt("login_id"));
					loginObj.setLoginName(rs.getString("login_name"));
					loginObj.setPassword(rs.getString("password"));
					loginObj.setManagerOrUserFlag(rs.getString("manager_or_user_flg"));
					loginObj.setAvailableAccountFlag(rs.getString("available_account_flg"));
					loginObj.setMembershipFlag("membership_flag");
				}

			} catch (SQLException e) {
				throw new UnsupportedOperationException(e);
			} catch (Exception e) {
				throw new IllegalStateException(e);
			} finally {
				//リソース開放
				if (smt != null) {
					try {
						smt.close();
					} catch (SQLException ignore) {
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (SQLException ignore) {
					}
				}
			}
			//呼び出し元にBookオブジェクトを返す
			return loginObj;
		}
		
		//ログイン情報を登録するメソッド
		public int insert(Login login) {
			Connection con = null;
			Statement smt = null;
			int rowsCnt;
			try{
				
				String sql = "INSERT INTO login_info ("
						+ "login_id, login_name, password, manager_or_user_flag, "
						+ "available_account_flag)"
						+ "VALUES('"
						+ login.getLoginId() +"',"+ login.getLoginName()
						+ ","+ login.getPassword() +", '"+ login.getManagerOrUserFlag() +"',"
						+ login.getAvailableAccountFlag() +"')";
				
				con = getConnection();
				smt = con.createStatement();
				
				rowsCnt = smt.executeUpdate(sql);
				
			}catch(Exception e){
				throw new IllegalStateException(e);
			}finally{
				if( smt != null ){
					try{smt.close();}catch(SQLException ignore){}
				}
				if( con != null ){
					try{con.close();}catch(SQLException ignore){}
				}
			}
			return rowsCnt;
		}

}
