package dao;

public class OrderedItemDAO {

}
