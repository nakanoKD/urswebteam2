package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.OrderedItem;

public class OrderedItemDAO {
	
	//データベース接続情報
	private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
	private static String URL = "jdbc:mariadb://localhost/sport_order_db";
	private static String USER = "root";
	private static String PASS = "root123";

	//データベース接続を行うメソッド
	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASS);

			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	public ArrayList<OrderedItem> selectAll() {
		Connection con = null;
		Statement smt = null;
		ArrayList<OrderedItem> ordered_list = new ArrayList<OrderedItem>();
		
		try {
			con = getConnection();
			smt = con.createStatement();

			//SQL文
			String sql = "SELECT order_info.*,detail_info.*,item_info.item_name,item_info.price,user_info.lastname,user_info.firstname"
						+ "FROM order_info"
						+ "INNER JOIN detail_info"
						+ "ON order_info.order_id = detail_info.order_id"
						+ "INNER JOIN item_info"
						+ "ON order_info.item_id = item_info.item_id"
						+ "INNER JOIN user_info"
			        	+ "ON order_info.user_id = user_info.user_id";
						
			//SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			//検索結果をArrayListに格納
			while (rs.next()) {
				OrderedItem orderedItem = new OrderedItem();
				orderedItem.setItemName(rs.getString("item_name"));
				orderedItem.setQuantity(rs.getInt("quantity"));
				orderedItem.setOrderDate(rs.getString("order_date"));
				orderedItem.setPrice(rs.getInt("price"));
				orderedItem.setFirstName(rs.getString("firstname"));
				orderedItem.setLastName(rs.getString("lastname"));
				ordered_list.add(orderedItem);
			}

		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}

		}
	return ordered_list;
	}
	
public OrderedItem selectByUserId(String userId){
	OrderedItem orderedItem = new OrderedItem();
	Connection con = null;
	Statement smt = null;
		
	try{
		con = getConnection();
		smt = con.createStatement();
			
		String sql = "SELECT order_info.*,detail_info.*,item_info.*,user_info.firstname,user_info.lastname"
					+ "FROM detail_info"
					+ "ON order_info.order_id = detail_info.order_id "
					+ "FROM item_info"
					+ "ON order_info.detail_id = detail_info.detail_id"
					+ "FROM user_info"
					+ "ON order_info.user_id = user_info.user_id"
					+ "WHERE user_id='"+userId+"'";
				
		ResultSet rs = smt.executeQuery(sql);
			
		if(rs.next()) {
			orderedItem.setFirstName(rs.getString("firstname"));
			orderedItem.setLastName(rs.getString("lastname"));
			orderedItem.setItemName(rs.getString("item_name"));
			orderedItem.setQuantity(rs.getInt("quantity"));
			orderedItem.setOrderDate(rs.getString("order_date"));
			orderedItem.setPrice(rs.getInt("price"));
			}
			
	} catch (SQLException e) {
		throw new UnsupportedOperationException(e);
		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if( smt != null ){
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		}
		return orderedItem;
	}
}
