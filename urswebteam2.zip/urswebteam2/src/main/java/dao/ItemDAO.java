package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Item;

public class ItemDAO {

	//データベース接続情報
	private static String RDB_DRIVE ="org.mariadb.jdbc.Driver";
	private static String URL ="jdbc:mariadb://localhost/sport_order_db";
	private static String USER ="root";
	private static String PASS ="root123";
	
	private static Connection getConnection() {
		try{
 			Class.forName(RDB_DRIVE);
 			Connection con = DriverManager.getConnection(URL, USER, PASS);
 			return con;
 		}catch(Exception e){
 			throw new IllegalStateException(e);
 		}
	}
	
	// 商品データを検索、リストに格納し返すメソッド
	public ArrayList<Item> selectAll(){
		
		Connection con = null;
		Statement smt = null;
		
		ArrayList<Item> itemList = new ArrayList<Item>();
		
		try{
			
			String sql = "select * from item_info";
			 
			con = getConnection();
			smt = con.createStatement();
			 
			ResultSet rs = smt.executeQuery(sql);
			 
			while(rs.next())
			{
				Item tempItem = new Item();
				tempItem.setItemId(rs.getInt("item_id"));
				tempItem.setItemName(rs.getString("item_name"));
				tempItem.setPrice(rs.getInt("price"));
				tempItem.setStock(rs.getInt("stock"));
				tempItem.setItemDetail(rs.getString("item_detail"));
				tempItem.setInsertDate(rs.getString("insert_date"));
				tempItem.setUpdateDate(rs.getString("update_date"));
				tempItem.setPhotoFile(rs.getString("photo_file"));
				
				itemList.add(tempItem);
			}
			
		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if( smt != null ){
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		 }
		 return itemList;
	}
	
	//商品データ登録
	public int insert(Item item){
		 
		Connection con = null;
		Statement smt = null;
		int rowsCnt;
		try{
			
			String sql = "INSERT INTO item_info ("
					+ "item_name, price, stock, item_detail, "
					+ "insert_date, update_date, photo_file)"
					+ "VALUES('"
					+ item.getItemName() +"',"+ item.getPrice()
					+ ","+ item.getStock() +", '"+ item.getItemDetail() +"',"
					+ "NOW(), NOW(), '"+ item.getPhotoFile() +"')";
			
			con = getConnection();
			smt = con.createStatement();
			
			rowsCnt = smt.executeUpdate(sql);
			
		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if( smt != null ){
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		}
		return rowsCnt;
	}
	
	//商品IDで検索するメソッド
	public Item selectByItemId(int itemId){
		
		Connection con = null;
		Statement smt = null;
		
		Item item = new Item();
		
		try{
			
			String sql = "select * from item_info where item_id = "
			+ itemId;
			
			con = getConnection();
			smt = con.createStatement();
			
			ResultSet rs = smt.executeQuery(sql);
			while(rs.next()) {
				item.setItemId(rs.getInt("item_id"));
				item.setItemName(rs.getString("item_name"));
				item.setPrice(rs.getInt("price"));
				item.setStock(rs.getInt("stock"));
				item.setItemDetail(rs.getString("item_detail"));
				item.setInsertDate(rs.getString("insert_date"));
				item.setUpdateDate(rs.getString("update_date"));
				item.setPhotoFile(rs.getString("photo_file"));
			}
		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);	
		}catch(Exception e){

		}finally{
			if( smt != null ){
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		}
		return item;
	}
	
	//商品情報を削除するメソッド
	public void delete(int itemId){
		
		Connection con = null;
		Statement smt = null;
		
		try{
		
			String sql = "delete from item_info WHERE item_id = '"+ itemId +"'";
			
			con = getConnection();
			smt = con.createStatement();
			
			int rowsCnt = smt.executeUpdate(sql);
			
		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if(smt!=null){
				try{smt.close();}catch(SQLException ignore){}
			}
			if(con!=null){
				try{con.close();}catch(SQLException ignore){}
			}
		}
	}
	
	//商品詳細に削除を載せる
	public void setDelete(int itemId){
		
		Connection con = null;
		Statement smt = null;
		
		try{
			
			String sql = "update item_info set item_detail = '削除' where item_id = "+ itemId;
			
			con = getConnection();
			smt = con.createStatement();
			
			int rowsCnt = smt.executeUpdate(sql);
			
		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if( smt != null ){
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		}
	}
	
	//商品情報更新
	public void update(Item item){
		 
		Connection con = null;
		Statement smt = null;
		
		try{
			
			String sql = "update item_info set "
					+ "item_name = '"+ item.getItemName() 
					+ "', price = "+ item.getPrice()
					+ ", stock = "+ item.getStock()
					+ ", item_detail = '"+ item.getItemDetail()
					+ "', update_date = now()"
					+ ", photo_file = '"+ item.getPhotoFile() +"'"
					+ " where item_id = "+ item.getItemId();
			
			con = getConnection();
			smt = con.createStatement();
			
			int rowsCnt = smt.executeUpdate(sql);
			
		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if( smt != null ){
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		}
	}
	
	//商品名でデータベースを検索し、該当データを返す
	public Item selectByItemName(String itemName) {
	
		Connection con = null;
		Statement smt = null;
		
		Item item = new Item();
		
		try{
			
			String sql = "select * from item_info where item_name = '"
			+ itemName + "';";
			
			con = getConnection();
			smt = con.createStatement();
			
			ResultSet rs = smt.executeQuery(sql);
			while(rs.next()) {
				item.setItemId(rs.getInt("item_id"));
				item.setItemName(rs.getString("item_name"));
				item.setPrice(rs.getInt("price"));
				item.setStock(rs.getInt("stock"));
				item.setItemDetail(rs.getString("item_detail"));
				item.setInsertDate(rs.getString("insert_date"));
				item.setUpdateDate(rs.getString("update_date"));
				item.setPhotoFile(rs.getString("photo_file"));
			}
		
		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		}catch(Exception e){

		}finally{
			if( smt != null ){
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		}
		return item;
	}
}
