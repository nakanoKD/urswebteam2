package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Sale;

public class SaleDAO {
	//DB情報をフィールド変数に定義
		private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
		private static String URL = "jdbc:mariadb://localhost/sport_order_db";
		private static String USER = "root";
		private static String PASSWORD = "root123";
		
		//情報をもとにDB接続を行うメソッド
		public Connection getConnection() {
			try {
				Class.forName(RDB_DRIVE);
				Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
				return con;
			} catch (Exception e) {
				throw new IllegalStateException(e);
			}
		}
		
		//order_infoとdetail_infoとitem_infoテーブルを結合して年月の売り上げ情報を取得するメソッド
		public ArrayList<Sale> selectBySales(String year, String month){
			Connection con = null;
			Statement smt = null;

			//return用ArrayList
			ArrayList<Sale> list = new ArrayList<Sale>();

			try {

				//SQL文
				String sql = "SELECT o.order_id, b.user_id sum(b.number_of_pieces) as b.number_of_pieces"
						+ ", c.item_name, c.price,  "
						+ "FROM detail_info o INNER JOIN order_info b ON o.detail_id=b.detail_id"
						+ " INNER JOIN item_info c  ON b.item_id=c.item_id"
						+" WHERE date LIKE '"+year+"-"+month+"%' GROUP BY b.order_id ORDER BY b.order_id;"
	;

				//オブジェクト生成
				con = getConnection();
				smt = con.createStatement();

				//SQL文発行
				ResultSet rs = smt.executeQuery(sql);

				//結果セットからデータを取り出し、Saleオブジェクトに格納
				while (rs.next()) {
					Sale objSale = new Sale();
					objSale.setOrderId(rs.getInt("order_id"));
					objSale.setUserId(rs.getInt("user_id"));
					objSale.setNumberOfPieces(rs.getInt("number_of_pieces"));
					objSale.setItemName(rs.getString("item_name"));
					objSale.setPrice(rs.getInt("price"));
					list.add(objSale);
				}
			} catch (SQLException e) {
				throw new UnsupportedOperationException(e);	
			}catch(Exception e) {
				throw new IllegalStateException(e);
				
			}finally {
				//リソース開放
				if (smt != null) {
					try {
						smt.close();
					} catch (SQLException ignore) {
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (SQLException ignore) {
					}
				}
			}
			//呼び出し元にArrayListを返す
			return list;
		}


}
