package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Order;

/*
 * 作成者：櫻井貴啓
 */
public class OrderDAO {
	//JDBCドライバ内部のDriverクラスパス
	private static final String RDB_DRIVE = "org.mariadb.jdbc.Driver";

	// 接続するMySQLデータベースパス
	private static final String URL = "jdbc:mariadb://localhost/sport_order_db";

	// データベースのユーザー名
	private static final String USER = "root";

	//データベースのパスワード
	private static final String PASSWORD = "root123";

	//DB接続をおこなう
	private static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(RDB_DRIVE);
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public void insert(Order order) {

		Connection con = null;
		Statement smt = null;

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "INSERT INTO order_info(order_id,user_id,quantity,order_date,total_amount,note,payment_date,shipping_date)"
					+ "VALUES('" + order.getOrderId() + "','" + order.getUserId() + "','" +
					"','" + order.getQuantity() + "',CURDATE(),'" + order.getTotalAmount() +
					"','" + order.getNote() + "','" + null + "','" + null + "')";

			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}
	
	public void update(Order order) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "UPDATE order_info SET payment_date = '" + order.getPaymentDate()
					+ "', shipping_date = '" + order.getShippingDate() + "' WHERE user_id ='"
					+ order.getUserId() + "'";
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				
			}
		}
	}
}

	public ArrayList<Order> selectByUserId(int userId) {

		Connection con = null;
		Statement smt = null;

		ArrayList<Order> orderList = new ArrayList<Order>();

		try {
			//SQL文
			String sql = "SELECT * FROM order_info WHERE user_id = '" + userId + "'";

			//Connectionオブジェクトを生成する
			con = getConnection();
			//Statementオブジェクトを生成する
			smt = con.createStatement();

			//SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			//検索結果をArrayListに格納
			if (rs.next()) {
				Order ordered = new Order();
				ordered.setOrderId(Integer.parseInt(rs.getString("orderId")));
				ordered.setUserId(Integer.parseInt(rs.getString("userId")));
				ordered.setQuantity(Integer.parseInt(rs.getString("quantity")));
				ordered.setOrderDate(rs.getString("orderDate"));
				ordered.setTotalAmount(Integer.parseInt(rs.getString("totalAmount")));
				ordered.setNote(rs.getString("text"));
				ordered.setPaymentDate(rs.getString("paymentDate"));
				ordered.setShippingDate(rs.getString("shippingDate"));
				orderList.add(ordered);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return orderList;
	}
	
	public Order selectByOrderId(int orderId) {

		Connection con = null;
		Statement smt = null;

		Order order = new Order();
		
		try {
			//SQL文
			String sql = "SELECT * FROM order_info INNER JOIN user_info ON order_info.user_id = user_info.user_id";

			//Connectionオブジェクトを生成する
			con = getConnection();
			//Statementオブジェクトを生成する
			smt = con.createStatement();

			//SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			//検索結果をArrayListに格納
			rs.next();
			order.setOrderId(rs.getInt("order_id"));
			order.setUserId(rs.getInt("user_id"));
			order.setQuantity(rs.getInt("quantity"));
			order.setOrderDate(rs.getString("order_date"));
			order.setTotalAmount(rs.getInt("total_amount"));
			order.setNote(rs.getString("note"));
			order.setPaymentDate(rs.getString("payment_date"));
			order.setShippingDate(rs.getString("shipping_date"));

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return order;
	}
	
public ArrayList<Order> selectAll(){
		
		Connection con = null;
		Statement smt = null;
		
		ArrayList<Order> orderList = new ArrayList<Order>();
		
		try{
			
			String sql = "select * from order_info";
			 
			con = getConnection();
			smt = con.createStatement();
			 
			ResultSet rs = smt.executeQuery(sql);
			 
			while(rs.next())
			{
				Order tempOrder = new Order();
				tempOrder.setOrderId(rs.getInt("order_id"));
				tempOrder.setUserId(rs.getInt("user_id"));
				tempOrder.setQuantity(rs.getInt("quantity"));
				tempOrder.setOrderDate(rs.getString("order_date"));
				tempOrder.setTotalAmount(rs.getInt("total_amount"));
				tempOrder.setNote(rs.getString("note"));
				tempOrder.setPaymentDate(rs.getString("payment_date"));
				tempOrder.setShippingDate(rs.getString("shipping_date"));
				
				orderList.add(tempOrder);
			}
			
		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if( smt != null ){
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		 }
		 return orderList;
	}
}
