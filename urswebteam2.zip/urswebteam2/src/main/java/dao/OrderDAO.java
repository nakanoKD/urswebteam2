package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import bean.Order;

/*
 * 作成者：櫻井貴啓
 */
public class OrderDAO {
	//JDBCドライバ内部のDriverクラスパス
	private static final String RDB_DRIVE = "org.mariadb.jdbc.Driver";
	
    // 接続するMySQLデータベースパス
	private static final String URL = "jdbc:mariadb://localhost/sport_order_db";
    
	// データベースのユーザー名
	private static final String USER = "root";
	
	//データベースのパスワード
	private static final String PASSWORD = "root123";

	//DB接続をおこなう
	 	private static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(RDB_DRIVE);
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	 public void insert(Order order) {
	 
		Connection con = null;
		Statement smt = null;
			
		try {
			con = getConnection();
			smt = con.createStatement();

			String sql =  "INSERT INTO order_info(order_id,user_id,detail_id,quantity,order_date,total_amount,note,payment_date,shipping_date)"
					+ "VALUES('"+order.getOrderId()+"','"+order.getUserId()+"','"+order.getDetailId()+
					"','"+order.getQuantity()+"',CURDATE(),'"+order.getTotalAmount()+
					"','"+order.getText()+"','"+null+"','"+null+"')";
					
			smt.executeUpdate(sql);
								
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}
}
