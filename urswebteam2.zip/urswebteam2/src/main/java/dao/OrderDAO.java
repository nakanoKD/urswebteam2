package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Order;

/*
 * 作成者：櫻井貴啓
 */
public class OrderDAO {
	//JDBCドライバ内部のDriverクラスパス
	private static final String RDB_DRIVE = "org.mariadb.jdbc.Driver";

	// 接続するMySQLデータベースパス
	private static final String URL = "jdbc:mariadb://localhost/sport_order_db";

	// データベースのユーザー名
	private static final String USER = "root";

	//データベースのパスワード
	private static final String PASSWORD = "root123";

	//DB接続をおこなう
	private static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(RDB_DRIVE);
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public int insert(Order order) {

		Connection con = null;
		Statement smt = null;

		int count;
		
		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "INSERT INTO order_info(user_id,quantity,order_date,total_amount,note,payment_date,shipping_date)"
					+ "VALUES(" + order.getUserId() + 
					"," + order.getQuantity() + ",CURDATE()," + order.getTotalAmount() +
					",'" + order.getNote() + "'," + null + "," + null + ")";

			count = smt.executeUpdate(sql);

		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return count;
	}
	
	//注文情報を更新
	public void update(Order order){
		 
		Connection con = null;
		Statement smt = null;
		
		try{
			
			String sql = "update order_info set "
					+ "user_id = "+ order.getUserId() 
					+ ", quantity = "+ order.getQuantity()
					+ ", order_date = CURDATE()"
					+ ", total_amount = "+ order.getTotalAmount()
					+ ", note = '"+ order.getNote()
					+ "', payment_date = null"
					+ ", shipping_date = null"
					+ " where order_id = "+ order.getOrderId() +";";
			
			con = getConnection();
			smt = con.createStatement();
			
			int rowsCnt = smt.executeUpdate(sql);
			
		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if( smt != null ){
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		}
	}
	
	//状況フラグ変更メソッド
	public void updateFlg(Order order) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "UPDATE order_info SET payment_date = '" + order.getPaymentDate()
					+ "', shipping_date = '" + order.getShippingDate() + "' WHERE order_id ='"
					+ order.getOrderId() + "'";
			smt.executeUpdate(sql);

		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				
				}
			}
		}
	}
	
	//order_infoのorder_idを取得するメソッド
	public int selectCount() {
		Connection con = null;
		Statement smt = null;
		int count = 0;
		
		try {
			con = getConnection();
			smt = con.createStatement();
			
			String sql = "select max(order_id) as id from order_info;";
			
			ResultSet rs = smt.executeQuery(sql);
			
			while(rs.next()) {
				count = rs.getInt("id");
			}
			
		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return count;
		
	}

	public ArrayList<Order> selectByUserId(int userId) {

		Connection con = null;
		Statement smt = null;

		ArrayList<Order> orderList = new ArrayList<Order>();

		try {
			//SQL文
			String sql = "SELECT * FROM order_info WHERE user_id = '" + userId + "'";

			//Connectionオブジェクトを生成する
			con = getConnection();
			//Statementオブジェクトを生成する
			smt = con.createStatement();

			//SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			//検索結果をArrayListに格納
			if (rs.next()) {
				Order ordered = new Order();
				ordered.setOrderId(Integer.parseInt(rs.getString("order_id")));
				ordered.setUserId(Integer.parseInt(rs.getString("user_id")));
				ordered.setQuantity(Integer.parseInt(rs.getString("quantity")));
				ordered.setOrderDate(rs.getString("order_date"));
				ordered.setTotalAmount(Integer.parseInt(rs.getString("total_amount")));
				ordered.setNote(rs.getString("note"));
				ordered.setPaymentDate(rs.getString("payment_date"));
				ordered.setShippingDate(rs.getString("shipping_date"));
				orderList.add(ordered);
			}

		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return orderList;
	}
	
	public Order selectByOrderId(int orderId) {

		Connection con = null;
		Statement smt = null;

		Order order = new Order();
		
		try {
			//SQL文
			String sql = "SELECT * FROM order_info INNER JOIN user_info ON order_info.user_id = user_info.user_id "
					+ "WHERE order_id =" + orderId + ";";

			//Connectionオブジェクトを生成する
			con = getConnection();
			//Statementオブジェクトを生成する
			smt = con.createStatement();

			//SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			//検索結果をArrayListに格納
			rs.next();
			order.setOrderId(rs.getInt("order_id"));
			order.setUserId(rs.getInt("user_id"));
			order.setQuantity(rs.getInt("quantity"));
			order.setOrderDate(rs.getString("order_date"));
			order.setTotalAmount(rs.getInt("total_amount"));
			order.setNote(rs.getString("note"));
			order.setPaymentDate(rs.getString("payment_date"));
			order.setShippingDate(rs.getString("shipping_date"));
		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return order;
	}
	
public ArrayList<Order> selectAll(){
		
		Connection con = null;
		Statement smt = null;
		
		ArrayList<Order> orderList = new ArrayList<Order>();
		
		try{
			
			String sql = "select * from order_info";
			 
			con = getConnection();
			smt = con.createStatement();
			 
			ResultSet rs = smt.executeQuery(sql);
			 
			while(rs.next())
			{
				Order tempOrder = new Order();
				tempOrder.setOrderId(rs.getInt("order_id"));
				tempOrder.setUserId(rs.getInt("user_id"));
				tempOrder.setQuantity(rs.getInt("quantity"));
				tempOrder.setOrderDate(rs.getString("order_date"));
				tempOrder.setTotalAmount(rs.getInt("total_amount"));
				tempOrder.setNote(rs.getString("note"));
				tempOrder.setPaymentDate(rs.getString("payment_date"));
				tempOrder.setShippingDate(rs.getString("shipping_date"));
				
				orderList.add(tempOrder);
			}
			
		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if( smt != null ){
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		 }
		 return orderList;
	}
}
