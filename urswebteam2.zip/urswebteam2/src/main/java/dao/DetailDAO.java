package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Detail;

public class DetailDAO {
	
	//データベース接続情報定義
	private static String RDB_DRIVE = "org.mariadb.jdbc.Driver";
	private static String URL = "jdbc:mariadb://localhost/sport_order_db";
	private static String USER = "root";
	private static String PASS = "root123";

	//データベースに接続するインスタンスメソッドgetConnection
	private static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASS);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	//データベースから全てのデータを検索するメソッド
	public ArrayList<Detail> selectAll(){
		Connection con = null;
		Statement smt = null;
		
		//リターン用ArrayList
		ArrayList<Detail> detailList = new ArrayList<Detail>();
		
		try {
			
			//SQL文
			String sql = "SELECT detail_info.item_id, detail_info.number_of_pieces, "
					+ "item_info.item_name, item_info.price,  FROM detail_info"
					+ "INNER JOIN item_info ON detail_info.item_id=item_info.item_info "
					+ "GROUP BY detail_info.item_id ORDER BY detail_info.item_id;";
			
			//オブジェクト生成
			con = getConnection();
			smt = con.createStatement();
			
			//SQL文発行
			ResultSet rs = smt.executeQuery(sql);
			
			//検索結果オブジェクトを配列に格納
			while (rs.next()) {
				Detail detail = new Detail();
				detail.setDetailId(rs.getInt("detail_id"));
				detail.setItemId(rs.getInt("item_id"));
				detail.setOrderId(rs.getInt("order_id"));
				detail.setNumberOfPieces(rs.getInt("number_of_prices"));
				detailList.add(detail);
			}

		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			//リソース開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		//検索結果配列を返す
		return detailList;
	}
	
	//商品IDで検索するメソッド
	public Detail selectByItemId(int itemId) {
		Connection con = null;
		Statement smt = null;
		
		Detail detail = new Detail();
		
		try{
			
			String sql = "select * from detail_info where item_id = "
			+ itemId;
			
			con = getConnection();
			smt = con.createStatement();
			
			ResultSet rs = smt.executeQuery(sql);
			while(rs.next()) {
				detail.setDetailId(rs.getInt("detail_id"));
				detail.setItemId(rs.getInt("item_id"));
				detail.setOrderId(rs.getInt("order_id"));
				detail.setNumberOfPieces(rs.getInt("number_of_pieces"));
			}
			
		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		}catch(Exception e){

		}finally{
			if( smt != null ){
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		}
		return detail;
	}

	// 注文IDで検索するメソッド
	public ArrayList<Detail> selectByOrderId(int orderId) {
		Connection con = null;
		Statement smt = null;
		
		ArrayList<Detail> detailList = new ArrayList<Detail>();
		
		try{
			
			String sql = "select * from detail_info where order_id = "
					+ orderId;
			
			con = getConnection();
			smt = con.createStatement();
			
			ResultSet rs = smt.executeQuery(sql);
			while(rs.next()) {
				Detail tempDetail = new Detail();
				tempDetail.setDetailId(rs.getInt("detail_id"));
				tempDetail.setItemId(rs.getInt("item_id"));
				tempDetail.setOrderId(rs.getInt("order_id"));
				tempDetail.setNumberOfPieces(rs.getInt("number_of_pieces"));
				detailList.add(tempDetail);
			}
			
		} catch (SQLException e) {
			throw new UnsupportedOperationException(e);
		}catch(Exception e){
			
		}finally{
			if( smt != null ){
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		}
		return detailList;
	}
}
