package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Item;
import bean.Login;
import bean.OrderedItem;
import bean.Sale;
import dao.ItemDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet("/confirmOrder")
public class ConfirmOrderServlet extends HttpServlet {
	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{
	
		String errorMsg = "";
		String nextPage = "";
		 
		try{
			
			HttpSession session = request.getSession();
			
			//文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");
			
			// エラーチェック
			//セッションからログインオブジェクトを取得
			Login loginInfo = (Login)session.getAttribute("logininfo");
			
			//セッション切れ確認
			if(loginInfo == null) {
			    errorMsg = "セッション切れの為、購入は出来ません。";
			    nextPage = "login";
			    return;
			}
			
			//セッションからorder_listを取得
			ArrayList<OrderedItem> list = (ArrayList<OrderedItem>) session.getAttribute("order_list");

			//空の時のエラー処理
			if (list.size() == 0) {
				errorMsg = "カートの中に何も無かったので購入は出来ません。";
				nextPage = "list";
				return;
			}
			
			
			// 一連DAOのインスタンス
			ItemDAO itemDao = new ItemDAO();
			
			// 必要数値の取得とsaleList作成
			int totalOrderQuantity = 0; // 合計注文数
			int totalPrice = 0; // 合計価格
			ArrayList<Sale> saleList = new ArrayList<Sale>();
			for(int i = 0; i < list.size(); i++) {
				// 登録に必要な数値の取得
				Item item = itemDao.selectByItemName(list.get(i).getItemName());
				totalPrice = item.getPrice() * list.get(i).getQuantity();
				totalOrderQuantity += list.get(i).getQuantity();
				
				//JSP表示用のsaleList作成
				Sale sale = new Sale();
				sale.setItemName(item.getItemName());
				sale.setPrice(item.getPrice());
				sale.setNumberOfPieces(list.get(i).getQuantity());
				saleList.add(sale); // データ追加
			}
			
			// JSP表示用リスト送信
			request.setAttribute("saleList",saleList);
			
			
		}catch (IllegalStateException e) {
			errorMsg ="DB接続エラーの為、購入は出来ません。 ";
			nextPage = "menu";
		}catch(Exception e){
			errorMsg ="予期せぬエラーが発生しました。<br>"+e; 
			nextPage = "menu";
		   
		}finally{
			// エラー画面へフォワード
 			if(!errorMsg.equals("")) {
 				request.setAttribute("errorMsg", errorMsg);
 				 request.setAttribute("nextPage", nextPage);
 				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
 				return;
 			}
 			
 			// 注文確認画面へフォワード
			request.getRequestDispatcher("/view/confirmOrder.jsp").forward(request, response);
		}
		
	}
}
