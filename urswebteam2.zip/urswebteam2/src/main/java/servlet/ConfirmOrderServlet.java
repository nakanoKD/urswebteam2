package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Item;
import bean.Login;
import bean.Order;
import bean.Sale;
import bean.User;
import dao.ItemDAO;
import dao.OrderDAO;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import util.SendMail;

@WebServlet("/confirmOrder")
public class ConfirmOrderServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//エラーの変数を定義
		String errorMsg = "";
		//cmd定義
		String cmd = "";

		try {
			//画面からの入力情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");

			//セッションからログインオブジェクトを取得
			HttpSession session = request.getSession();
			Login logininfo = (Login) session.getAttribute("logininfo");
			//セッション切れ確認
			if (logininfo == null) {
				errorMsg = "セッション切れの為、注文できません。";
				cmd = "logout";
				return;
			}

			//ログインID取得
			int loginId = logininfo.getLoginId();
			//ログインIDからユーザー情報取得
			UserDAO userDao = new UserDAO();
			User user = userDao.selectByLoginId(loginId);

			//ItemDAO,OrderDAOオブジェクト生成
			ItemDAO itemDao = new ItemDAO();
			OrderDAO orderDao = new OrderDAO();

			//セッションからorder_listを取得
			ArrayList<Order> order_list = (ArrayList<Order>) session.getAttribute("order_list");

			//空の時のエラー処理
			if (order_list == null) {
				errorMsg = "カートの中に何も無かったので購入は出来ません。";
				cmd = "list";
				return;
			}

			//order_list分だけメソッド呼び出し
			String text = "";
			int total = 0;

			//メール本文
			text = "ユニフォームのご購入ありがとうざいます。\n"
					+ "以下内容でご注文を受け付けましたので、ご連絡致します。\n";
			text += "No. 商品名　価格\n";

			//空の時のエラー処理
			if (order_list == null) {
				errorMsg = "カートの中に何も無かったので購入は出来ません。";
				cmd = "list";
				return;
			}
			//結果格納用配列
			ArrayList<Sale> list = new ArrayList<Sale>();

			for (int i = 0; i < order_list.size(); i++) {
				Item item = itemDao.selectByItemId(order_list.get(i).getOrderId());
				orderDao.insert(order_list.get(i));
				total += item.getPrice() * order_list.get(i).getQuantity();
				text += item.getItemId() + " " + item.getItemName() + "　" + item.getPrice()
						+ " " + "円" + order_list.get(i).getQuantity() + "着\n";
				Sale sale = new Sale(item, order_list.get(i).getQuantity());
				list.add(sale);
			}

			text += "合計" + total + "円\n"
					+ "またのご利用よろしくお願いします。\n";

			//取得したListをリクエストスコープへ登録
			request.setAttribute("sale_list", list);

			//order_listの注文内容をメール送信
			SendMail sendMail = new SendMail();
			sendMail.sendMail(text);

			//sessionのorder_list情報をクリア
			session.setAttribute("order_list", null);

		} catch (UnsupportedOperationException e) {
			errorMsg = "クエリ発行に失敗しました。";
			cmd = "logout";
		} catch (IllegalStateException e) {
			errorMsg = "DB接続エラーの為、書籍詳細は表示できませんでした。";
			cmd = "logout";
		} finally {
			if (errorMsg.equals("")) {
				//buyConfirm.jspにフォワード
				request.getRequestDispatcher("/view/confirmOrder.jsp").forward(request, response);
			} else {
				//エラーメッセージを持ってerror.jspにフォワード
				request.setAttribute("cmd", cmd);
				request.setAttribute("errorMsg", errorMsg);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
