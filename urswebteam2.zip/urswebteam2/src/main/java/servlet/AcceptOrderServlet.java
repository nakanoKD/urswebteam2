package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Detail;
import bean.Item;
import bean.Login;
import bean.Order;
import bean.OrderedItem;
import bean.Sale;
import bean.User;
import dao.DetailDAO;
import dao.ItemDAO;
import dao.OrderDAO;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import util.SendMail;


@WebServlet("/acceptOrder")
public class AcceptOrderServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//エラーの変数を定義
		String errorMsg = "";
		//cmd定義
		String nextPage = "";

		try {
			//画面からの入力情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");

			//セッションからログインオブジェクトを取得
			HttpSession session = request.getSession();
			Login logininfo = (Login) session.getAttribute("logininfo");
			
			//セッション切れ確認
			if (logininfo == null) {
				errorMsg = "セッション切れの為、注文できません。";
				nextPage = "login";
				return;
			}

			//DAOオブジェクト生成
			ItemDAO itemDao = new ItemDAO();
			OrderDAO orderDao = new OrderDAO();
			DetailDAO detailDao = new DetailDAO();

			//セッションからorder_listを取得
			ArrayList<OrderedItem> order_list = (ArrayList<OrderedItem>) session.getAttribute("order_list");

			//空の時のエラー処理
			if (order_list == null) {
				errorMsg = "カートの中に何も無かったので購入は出来ません。";
				nextPage = "list";
				return;
			}

			//order_list分だけメソッド呼び出し
			String text = "";
			int total = 0;
			int quantity = 0;
			String note = "";

			//メール本文
			text = "ユニフォームのご購入ありがとうざいます。\n"
					+ "以下内容でご注文を受け付けましたので、ご連絡致します。\n";
			text += "No. 商品名　　　　価格\n";

			//結果格納用配列
			ArrayList<Sale> list = new ArrayList<Sale>();
			
			//Orderオブジェクト生成
			Order order = new Order();
			order.setUserId(order_list.get(0).getUserId());
			orderDao.insert(order);
			int orderId = orderDao.selectCount();
			
			for (int i = 0; i < order_list.size(); i++) {
				Item item = itemDao.selectByItemName(order_list.get(i).getItemName());	
				total += item.getPrice() * order_list.get(i).getQuantity();
				quantity += order_list.get(i).getQuantity();
				note += order_list.get(i).getNote() + "\n";
				text += item.getItemId() + " " + item.getItemName() + "　" + item.getPrice()
						+ " " + "円" + order_list.get(i).getQuantity() + "着\n";
				Sale sale = new Sale(item, order_list.get(i).getQuantity());
				list.add(sale);
				Detail detail = new Detail();
				detail.setOrderId(orderId);
				detail.setItemId(item.getItemId());
				detail.setNumberOfPieces(order_list.get(i).getQuantity());
				detailDao.insert(detail);
			}
			
			Order orderset = orderDao.selectByOrderId(orderId);
			orderset.setUserId(order_list.get(0).getUserId());
			orderset.setQuantity(quantity);
			orderset.setTotalAmount(total);
			orderset.setNote(note);
			orderDao.update(orderset); //DBへ注文情報を登録

			text += "合計" + total + "円\n"
					+ "またのご利用よろしくお願いします。\n";

			//取得したListをリクエストスコープへ登録
			request.setAttribute("sale_list", list);

			//order_listの注文内容をメール送信
			UserDAO userDao = new UserDAO();
			User user = userDao.selectByUserId(order_list.get(0).getUserId());
			String email = user.getEmail();
			SendMail sendMail = new SendMail();
			sendMail.sendMail(text, email);

			//sessionのorder_list情報をクリア
			session.setAttribute("order_list", null);

		} catch (UnsupportedOperationException e) {
			errorMsg = "クエリ発行に失敗しました。";
			nextPage = "logout";
		} catch (IllegalStateException e) {
			errorMsg = "DB接続エラーの為、購入は表示できませんでした。";
			nextPage = "logout";
		} finally {
			if (errorMsg.equals("")) {
				//注文完了画面にフォワード
				request.getRequestDispatcher("/view/acceptOrder.jsp").forward(request, response);
			} else {
				//エラーメッセージを持ってerror.jspにフォワード
				request.setAttribute("nextPage", nextPage);
				request.setAttribute("errorMsg", errorMsg);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
