package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Detail;
import bean.Item;
import bean.Login;
import dao.ItemDAO;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/acceptOrder")
public class AcceptOrderServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{
	
		String errorMsg = "";
		 
		try{
			
			HttpSession session = request.getSession();
			
			//文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");
			
			// エラーチェック
			//セッションからログインオブジェクトを取得
			Login loginInfo = (Login)session.getAttribute("loginInfo");
			//セッション切れ確認
			if(loginInfo == null) {
			    errorMsg += "セッション切れの為、購入は出来ません。";
			    request.setAttribute("cmd", "logout");
			}
			
			// セッションから現在のカートを取得
			ArrayList<Detail> detailList = (ArrayList<Detail>)session.getAttribute("detailList");
			if(detailList == null) {
				errorMsg += "カートの中に何も無かったので購入は出来ません。";
				request.setAttribute("cmd", "menu");
			}
			
			// セッションからorderIdを取得
			String orderId = (String)session.getAttribute("orderId");
			if(orderId == null) {
				errorMsg += "カート情報を取得できないので購入は出来ません。";
				request.setAttribute("cmd", "menu");
			}
			
			// エラーがあれば早期リターン
			if(!errorMsg.equals("")) {
				return;
			}
			
			// 注文をDBに登録
			// 一連DAOのインスタンス化
			OrderedItemDAO OrderedItemDao = new OrderedItemDAO();
			UserDAO userDao = new UserDAO();
			ItemDAO itemDao = new ItemDAO();
			
			// 必要数値の取得とJSP表示用にsaleList作成
			int totalOrderQuantity = 0; // 合計注文数
			int totalPrice = 0; // 合計価格
			ArrayList<Sale> saleList = new ArrayList<Sale>();
			for(int i = 0; i < detailList.size(); i++) {
				// 登録に必要な数値の取得
				Item item = itemDao.selectByItemId(detailList.get(i).getItemId());
				totalPrice = item.getPrice() * detailList.get(i).getNumberOfPieces();
				totalOrderQuantity += detailList.get(i).getNumberOfPieces();
				
				//JSP表示用のsaleList作成
				Sale sale = new Sale();
				sale.setName(item.getItemName());
				sale.setPrice(item.getPrice());
				sale.setQuantity(detailList.get(i).getNumberOfPieces());
				saleList.add(sale); // データ追加
			}
			
			// １件の注文データを作成
			OrderedItem orderedItem = new OrderedItem();
			orderedItem.setOrderId(Integer.parseInt(orderId));
			orderedItem.setUserId(userDao.selectByLoginId(loginInfo.getLoginId()));
			orderedItem.setQuantity(totalOrderQuantity);
			orderedItem.setTotalAmount(totalPrice);
			orderedItem.setNote("");
			
			// 注文情報を更新
			orderedItemDao.update(orderedItem);
			
			// JSP表示用リスト送信
			request.setAttribute("saleList",saleList);
			
			// カート情報をクリア
			session.setAttribute("detailList",null);
			
		}catch (IllegalStateException e) {
			errorMsg ="DB接続エラーの為、購入は出来ません。 ";
			request.setAttribute("cmd", "logout");
		}catch(Exception e){
			errorMsg ="予期せぬエラーが発生しました。<br>"+e; 
			request.setAttribute("cmd", "logout");
		}finally{
			// エラー画面へフォワード
 			if(!errorMsg.equals("")) {
 				request.setAttribute("errorMsg", errorMsg);
 				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
 				return;
 			}
 			
 			// メニュー画面へフォワード
			request.getRequestDispatcher("/view/menu.jsp").forward(request, response);
		}
		
	}
}
