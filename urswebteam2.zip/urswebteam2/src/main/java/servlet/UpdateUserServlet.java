package servlet;

import java.io.IOException;

import bean.User;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/updateUser")
public class UpdateUserServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String error = null;

		try {
			//パラメータの取得
			String email = (request.getParameter("email"));
			String firstName = (request.getParameter("firstName"));
			String lastName = (request.getParameter("lastName"));
			String firstNameRuby = (request.getParameter("firstNameRuby"));
			String lastNameRuby = (request.getParameter("lastNameRuby"));
			String postalCode = (request.getParameter("postalCode"));
			String prefecture = (request.getParameter("prefecture"));
			String city = (request.getParameter("city"));
			
			//DAOオブジェクトの生成
			UserDAO objDao = new UserDAO();

			//Userオブジェクトの生成
			User newUser = new User();
			
			//画面からの入力情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");
			
			//エラーあり
			
			//メールアドレスが入力されていない場合
			if (newUser.getEmail() != null) {
				error = "メールアドレス未入力の為、更新処理は行えませんでした。";
				return;

			//名字を入力時に空文字が入力された場合
			if (newUser.getFirstName().equals("")) {
				error = "名字が未入力の為、更新処理は行えませんでした。 ";
				return;

			//名前を入力時に空文字が入力された場合
			if (newUser.getLastName().equals("")) {
				error = "名前が未入力の為、更新処理は行えませんでした。 ";
				return;
			
			//名字(カナ)を入力時に空文字が入力された場合
			if (newUser.getFirstNameRuby().equals("")) {
				error = "名字(カナ)が未入力の為、更新処理は行えませんでした。 ";
				return;
				
			//名前(カナ)を入力時に空文字が入力された場合
			if (newUser.getLastName().equals("")) {
				error = "名前(カナ)が未入力の為、更新処理は行えませんでした。 ";
				return;
				
			//郵便番号の確認
			for (int i = 0; i < postalCode.length(); i++) {
				//ハイフンが入る場合
				if(i == 3) {
					continue;
				}
				
				//数値が入る場合
				if (Character.isDigit(postalCode.charAt(i))) {
					continue;
				
				//数値以外が入っている場合
				} else {
					error = " 郵便番号の値が不正";
					break;
				}
			}
			
			//都道府県が選択されていない場合
			if (newUser.getPrefecture().equals("")) {
				error = "都道府県が選択されていない為、更新処理は行えませんでした。 ";
				return;
				
			//市町村～番地が選択されていない場合
			if (newUser.getCity().equals("")) {
				error = "市町村～番地が未入力の為、更新処理は行えませんでした。 ";
				return;
				
			//エラーなし
			} else {
				//パラメータの設定
				newUser.setEmail(email);
				newUser.setFirstName(firstName);
				newUser.setLastName(lastName);
				newUser.setFirstNameRuby(firstNameRuby);
				newUser.setLastNameRuby(lastNameRuby);
				newUser.setPostalCode(postalCode);
				newUser.setPrefecture(prefecture);
				newUser.setCity(city);

				//Userオブジェクトに格納されたユーザー情報でデータベースを更新
				objDao.update(user);
			}

		//DB接続エラーの場合
		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、更新処理は行えませんでした。";

		} finally {
			//エラーなし
			if (error == null) {
				//userMenu.jspへフォワード
				request.getRequestDispatcher("/view/userMenu.jsp").forward(request, response);

			//エラーあり
			} else {
				//errorをリクエストスコープに"error"という名前で格納する
				request.setAttribute("error", error);
				//error.jspにフォワード
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}
	}
}
