package servlet;

import java.io.IOException;

import bean.Login;
import bean.User;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/updateUser")
public class UpdateUserServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String errorMsg = "";
		String nextPage = "";

		try {
			//セッションからログインオブジェクトを取得
			HttpSession session = request.getSession();
			Login logininfo = (Login) session.getAttribute("logininfo");

			//セッション切れ確認
			if (logininfo == null) {
				errorMsg = "セッション切れの為、注文できません。";
				nextPage = "logout";
				return;
			}
			
			//画面からの入力情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");
			
			//パラメータの取得
			String email = (request.getParameter("email"));
			String firstName = (request.getParameter("firstName"));
			String lastName = (request.getParameter("lastName"));
			String firstNameRuby = (request.getParameter("firstNameRuby"));
			String lastNameRuby = (request.getParameter("lastNameRuby"));
			String sex = request.getParameter("sex");
			String postalCode = (request.getParameter("postalCode"));
			String prefecture = (request.getParameter("prefecture"));
			String city = (request.getParameter("city"));
			
			//DAOオブジェクトの生成
			UserDAO objDao = new UserDAO();
		
			//Userオブジェクト取得
			int loginId = logininfo.getLoginId();
			User newUser = objDao.selectByLoginId(loginId);
			
			//条件分岐
			//メールアドレスが入力されていない場合
			if (!email.equals("")) {
				newUser.setEmail(email);
			}
			//名字を入力時に空文字が入力された場合
			if (!lastName.equals("")) {
				newUser.setLastname(lastName);
			}
			//名前を入力時に空文字が入力された場合
			if (!firstName.equals("")) {
				newUser.setFirstname(firstName);
			}
			//名字(カナ)を入力時に空文字が入力された場合
			if (!lastNameRuby.equals("")) {
				newUser.setLastnameRuby(lastNameRuby);
			}	
			//名前(カナ)を入力時に空文字が入力された場合
			if (!firstNameRuby.equals("")) {
				newUser.setFirstnameRuby(firstNameRuby);
			}	
			//性別入力時に空文字が入力された場合
			if(!sex.equals("")) {
				newUser.setSex(sex);
			}
			//郵便番号の確認
			for (int i = 0; i < postalCode.length(); i++) {
				//ハイフンが入る場合
				if(i == 3) {
					continue;
				}
				
				//数値が入る場合
				if (Character.isDigit(postalCode.charAt(i))) {
					continue;
				
				//数値以外が入っている場合
				} else {
					errorMsg = " 郵便番号の値が不正の為、更新処理は行えませんでした。";
					nextPage = "menu";
					break;
				}
			}
			if(!postalCode.equals("")&&errorMsg.equals("")) {
				newUser.setPostalCode(postalCode);
			}
			
			//都道府県が選択されていない場合
			if (!prefecture.equals("")) {
				newUser.setPrefecture(prefecture);
			}
			//市町村～番地が選択されていない場合
			if (!city.equals("")) {
				newUser.setCity(city);
			}	
			
			//Userオブジェクトに格納されたユーザー情報でデータベースを更新
			objDao.update(newUser);
		
		}catch(UnsupportedOperationException e) {
			errorMsg = "クエリ発行に失敗しました。";
			nextPage = "login";
		//DB接続エラーの場合
		} catch (IllegalStateException e) {
			errorMsg = "DB接続エラーの為、更新処理は行えませんでした。";
			nextPage = "login";
		} finally {
			//エラーなし
			if (errorMsg.equals("")) {
				//userMenu.jspへフォワード
				request.getRequestDispatcher("/view/menu.jsp").forward(request, response);

			//エラーあり
			} else {
				//errorをリクエストスコープに"error"という名前で格納する
				request.setAttribute("errorMsg", errorMsg);
				request.setAttribute("nextPage", nextPage);
				//error.jspにフォワード
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
