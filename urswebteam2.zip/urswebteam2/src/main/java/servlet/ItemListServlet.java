package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Item;
import dao.ItemDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/itemList")
public class ItemListServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//画面からの入力情報を受け取るためのエンコードを設定
		request.setCharacterEncoding("UTF-8");
		
		String errorMsg = null;
		String nextPage = "";
		
		try {
			List(request,response);		
			
		}catch(UnsupportedOperationException e) {
			errorMsg = "クエリ発行に失敗しました。";
			nextPage = "login";
		//DB接続エラーの場合
		} catch (IllegalStateException e) {
			errorMsg = "DB接続エラーの為、商品一覧表示は行えませんでした。";
			nextPage = "login";

		} finally {
			//エラーなし
			if (errorMsg == null) {
				//itemList.jspにフォワード
				request.getRequestDispatcher("/view/itemList.jsp").forward(request, response);

			//エラーあり
			} else {
				//errorをリクエストスコープに"errorMsg"という名前で格納する
				request.setAttribute("errorMsg", errorMsg);
				request.setAttribute("nextPage", nextPage);
				//error.jspにフォワード
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		
		String errorMsg = null;
		String nextPage = "";
				
		try {
			List(request,response);
		}catch(UnsupportedOperationException e) {
			errorMsg = "クエリ発行に失敗しました。";
			nextPage = "login";
		//DB接続エラーの場合
		} catch (IllegalStateException e) {
			errorMsg = "DB接続エラーの為、商品一覧表示は行えませんでした。";
			nextPage = "login";

		} finally {
			//エラーなし
			if (errorMsg == null) {
				//itemList.jspにフォワード
				request.getRequestDispatcher("/view/itemList.jsp").forward(request, response);

			//エラーあり
			} else {
				//errorをリクエストスコープに"errorMsg"という名前で格納する
				request.setAttribute("errorMsg", errorMsg);
				request.setAttribute("nextPage", nextPage);
				//error.jspにフォワード
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

		
	private void List(HttpServletRequest request, HttpServletResponse response) {
			//ItemDAOオブジェクトの生成
			ItemDAO objItemDao = new ItemDAO();
			
			//関連メソッドを呼び出し、戻り値としてItemオブジェクトのリストを取得する
			ArrayList<Item> itemList = objItemDao.selectAll();

			//itemListをリクエストスコープに"item_list"という名前で格納する
			request.setAttribute("item_list", itemList);
	}
}
