package servlet;

import java.io.IOException;

import bean.Item;
import dao.itemDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/insert")
public class insertItemServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//エラーメッセージ用変数、cmd
		String error = "";
		String cmd = "";
		
		try {
			
			//DAOクラスのオブジェクト生成
			itemDAO itemDao = new itemDAO();
			
			//登録する商品情報を格納するItemオブジェクト生成
			Item item = new Item();
			
			//画面からの入力情報受け取る
			String itemName = request.getParameter("name");
			int price = Integer.parseInt(request.getParameter("price"));
			int stockQuantity = Integer.parseInt(request.getParameter("stockQuantity"));
			String itemDetail = request.getParameter("itemDetail");
			
			//入力チェック
			if(itemName.equals("") || itemName == null) {
				error = "商品名が未入力の為、商品登録処理は行えませんでした。";
				cmd = "list";
				return;
			}
			if(itemDao.selectBy(itemName).getitemName() != null) { 
				//重複チェック
				error = "入力商品は既に登録済みの為、商品登録処理は行えませんでした。";
				cmd = "list";
				return;
			}
			item.setItemName(itemName);
			
			//入力チェック
			if(price == 0) {
				error = "価格が未入力の為、書籍登録処理は行えませんでした。";
				cmd = "list";
				return;
			}
			item.setPrice(price);
			
			//入力チェック
			if(stockQuantity == 0) {
				error = "個数が未入力の為、書籍登録処理は行えませんでした。";
				cmd = "list";
				return;
			}
			
			//insert()メソッド呼び出し
			itemDao.insert(item);
			
		}catch(NumberFormatException e) {
			error = "価格または個数が不正です。整数値を入力してください。";
			cmd = "menu";
			
		}catch(UnsupportedOperationException e) {
			error = "クエリ発行に失敗しました。";
			cmd = "logout";
		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、商品登録処理は行えませんでした。";
			cmd = "logout";
		}finally {
			if(error.equals("")) {
				//ListServletへフォワード
				request.getRequestDispatcher("/list").forward(request, response);
			}else {
			//エラーメッセージ、cmd情報を持ってerror.jspへフォワード
			request.setAttribute("error", error);
			request.setAttribute("cmd", cmd);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
		
	}
}
