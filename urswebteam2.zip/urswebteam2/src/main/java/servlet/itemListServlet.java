package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Administor;
import dao.administorDAO;
import dao.userDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/itemList")
public class itemListServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String error = null;

		try {
			//userDAOオブジェクトの生成
			userDAO objUserDao = new userDAO();
			
			//administorDAOオブジェクトの生成
			administorDAO objAdministorDao = new administorDAO();

			//画面からの入力情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");
			
			//関連メソッドを呼び出し、戻り値としてUserオブジェクトのリストを取得する
			ArrayList<User> userList = objUserDao.selectAll();

			//関連メソッドを呼び出し、戻り値としてAdministorオブジェクトのリストを取得する
			ArrayList<Administor> administorList = objAdministorDao.selectAll();
			
			//userListをリクエストスコープに"administor_list"という名前で格納する
			request.setAttribute("user_list", userList);

			//administorListをリクエストスコープに"administor_list"という名前で格納する
			request.setAttribute("administor_list", administorList);

		//DB接続エラーの場合
		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、商品一覧表示は行えませんでした。";

		} finally {
			//エラーなし
			if (error == null) {
				//order.jspにフォワード
				request.getRequestDispatcher("/view/order.jsp").forward(request, response);

			//エラーあり
			} else {
				//errorをリクエストスコープに"error"という名前で格納する
				request.setAttribute("error", error);
				//error.jspにフォワード
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
