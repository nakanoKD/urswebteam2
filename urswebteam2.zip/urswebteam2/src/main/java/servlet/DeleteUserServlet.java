package servlet;

import java.io.IOException;

import bean.Login;
import bean.User;
import dao.LoginDAO;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/deleteUser")
public class DeleteUserServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//エラーメッセージ用変数、cmd情報
		String errorMsg = "";
		String nextPage = "";
		
		try {
			
			//セッションからログインオブジェクトを取得
			HttpSession session = request.getSession();
			Login logininfo = (Login) session.getAttribute("logininfo");

			//セッション切れ確認
			if (logininfo == null) {
				errorMsg = "セッション切れの為、注文できません。";
				nextPage = "login";
				return;
			}
			int loginId = logininfo.getLoginId();
			
			//UserDAOをインスタンス化し、関連メソッド(ユーザー削除処理)を呼び出す
			UserDAO userDao = new UserDAO();
			//ユーザーID取得
			User user = userDao.selectByLoginId(loginId);
			LoginDAO loginDao = new LoginDAO();
			int userId = user.getUserId();
			userDao.delete(userId);
			loginDao.delete(loginId);
			
		}catch(UnsupportedOperationException e) {
			errorMsg = "クエリ発行に失敗しました。";
			nextPage = "login";
		}catch(IllegalStateException e) {
			//エラーメッセージ設定
			errorMsg = "DB接続エラーの為、ユーザー削除は行えません。";
			nextPage = "login";
			
		}finally {
			if(errorMsg.equals("")) {
				//login.jspへフォワード
				request.getRequestDispatcher("/view/login.jsp").forward(request, response);
			}else {
				//エラーメッセージを持ってerror.jspへフォワード
				request.setAttribute("errorMsg", errorMsg);
				request.setAttribute("nextPage", nextPage);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}	
		}
	}

}
