package servlet;


	import java.io.IOException;
import java.util.ArrayList;

import bean.Item;
import bean.Login;
import bean.OrderedItem;
import bean.Sale;
import bean.User;
import dao.ItemDAO;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

	@WebServlet("/showCart")
	public class ShowCartServlet extends HttpServlet {
		protected void doGet(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {

				//エラーの変数を定義
				String errorMsg = "";
				//cmd定義
				String nextPage = "";

				try {
					//セッションからログインオブジェクトを取得
					HttpSession session = request.getSession();
					Login logininfo = (Login) session.getAttribute("logininfo");

					//セッション切れ確認
					if (logininfo == null) {
						errorMsg = "セッション切れの為、注文できません。";
						nextPage = "login";
						return;
					}
					//画面からの入力情報を受け取るためのエンコードを設定
					request.setCharacterEncoding("UTF-8");
				
					// delnoの入力パラメータを取得する
					String delno = (String) request.getParameter("delno");
				
					//セッションから"order_list"を取得する
					ArrayList<OrderedItem> order_list = (ArrayList<OrderedItem>) session.getAttribute("order_list");
				
					//delnoが「null」でない場合、order_listから該当商品を削除する
					if (delno != null) {
						order_list.remove(Integer.parseInt(delno));
						session.setAttribute("order_list", order_list);
					}	
				
					//ログインID取得
					int loginId = logininfo.getLoginId();
					
					//ログインIDからユーザー情報取得
					UserDAO userDao = new UserDAO();
					User user = userDao.selectByLoginId(loginId);
				
					//ItemDAO,オブジェクト生成
					ItemDAO itemDao = new ItemDAO();
				
					//空の時のエラー処理
					if (order_list.size() == 0) {
					errorMsg = "カートの中に何も無かったので購入は出来ません。";
					nextPage = "list";
					return;
					}
					
					//結果格納用配列
					ArrayList<Sale> list = new ArrayList<Sale>();
					
					//order_list分だけメソッド呼び出し
					int total = 0;
					for (int i = 0; i < order_list.size(); i++) {
					Item item = itemDao.selectByItemName(order_list.get(i).getItemName());
					Sale sale = new Sale(item, order_list.get(i).getQuantity());
					list.add(sale);
					}
				
					//取得したListをリクエストスコープへ登録
					request.setAttribute("sale_list", list);
				
				} catch (IllegalStateException e) {
					errorMsg = "DB接続エラーの為、カート状況は確認出来ません。";
					nextPage = "login";

				} finally {
					// エラーの有無でフォワード先を呼び分ける
					if (errorMsg.equals("")) {
						// エラーなし：showCart.jspにフォワード
						request.getRequestDispatcher("/view/showCart.jsp").forward(request, response);
					} else {
						//エラーあり：error.jspにフォワード
						request.setAttribute("errorMsg", errorMsg);
						request.setAttribute("nextPage", nextPage);
						request.getRequestDispatcher("/view/error.jsp").forward(request, response);
					}
				}
			}
	}
	
