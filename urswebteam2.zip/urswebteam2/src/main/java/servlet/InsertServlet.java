package servlet;

import java.io.IOException;

import bean.Book;
import dao.BookDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/insert")
public class InsertServlet extends HttpServlet {

	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{
		
		String error = "";
		
		try{
			
			BookDAO bookDao = new BookDAO();
			Book book = new Book();
			
			//文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");
			
			//パラメータの取得
			String isbn = request.getParameter("isbn");
			String title = request.getParameter("title");
			String price = request.getParameter("price");
			book.setIsbn(isbn);
			book.setTitle(title);
			book.setPrice(price);
			
			// エラーチェック
			if (isbn.equals("")) {
				error += "ISBNが未入力の為、";
			}
			if (title.equals("")) {
				error += "TITLEが未入力の為、";
			}
			if (price.equals("")) {
				error += "価格が未入力の為、";
			}
			if (bookDao.selectByIsbn(isbn).getIsbn() != null) {
				error += "入力ISBNは既に登録済みの為、";
			}
			for (int i = 0; i < price.length(); i++) {

				if (Character.isDigit(price.charAt(i))) {
					continue;
				} else {
					error += "価格の値が不正な為、";
					break;
				}
			}

			// エラーメッセージが無い場合登録処理
			if (error.equals("")) {
				//1件登録メソッドを呼び出し
				bookDao.insert(book);
			} else {
				error += "書籍登録処理は行えませんでした。";
				request.setAttribute("cmd", "list");
			}
		}catch (IllegalStateException e) {
			error ="DB接続エラーの為、書籍登録処理は行えませんでした。";
			request.setAttribute("cmd", "logout");
		}catch(Exception e){
			error ="予期せぬエラーが発生しました。<br>"+e;
			request.setAttribute("cmd", "logout");
		}finally{
			// error.jspへフォワード
 			if(!error.equals("")) {
 				request.setAttribute("error", error);
 				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
 				return;
 			}
 			
 			// listServletへフォワード
			request.getRequestDispatcher("/list").forward(request, response);
		}
	}
}
