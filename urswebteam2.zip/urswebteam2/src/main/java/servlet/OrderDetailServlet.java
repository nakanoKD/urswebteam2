package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Detail;
import bean.Item;
import bean.Login;
import bean.Sale;
import dao.DetailDAO;
import dao.ItemDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/orderDetail")
public class OrderDetailServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String errorMsg = "";
		try {
			//セッションからログインオブジェクトを取得
			HttpSession session = request.getSession();	
			Login logininfo = (Login)session.getAttribute("logininfo");
			//セッション切れ確認
			if(logininfo == null) {
				errorMsg = "セッション切れの為、詳細を確認できません。";
				request.setAttribute("nextPage", "login");
				return;
			}
			
			String orderId = request.getParameter("orderId");
			
			if(!errorMsg.equals(""))return;
			
			// 表示情報のリストを作成
			ArrayList<Sale> saleList = new ArrayList<Sale>();
			
			// 使用するDAOのインスタンス化
			DetailDAO detailDao = new DetailDAO();
			ItemDAO itemDao = new ItemDAO();
			
			// 注文IDから詳細・商品情報を取得する
			ArrayList<Detail> detailList = detailDao.selectByOrderId(Integer.parseInt(orderId));
			for(int i = 0; i < detailList.size(); i++) {
				
				Item item = itemDao.selectByItemId(detailList.get(i).getItemId());
				
				// １件のデータを格納
				// saleに入れるものがおかしい
				Sale sale = new Sale();
				sale.setItemName(item.getItemName());
				sale.setPrice(item.getPrice());
				sale.setNumberOfPieces(detailList.get(i).getNumberOfPieces());
				saleList.add(sale);
			}
			
			// リクエストスコープに格納
			request.setAttribute("saleList", saleList);
		
		//DB接続エラーの場合
		} catch (IllegalStateException e) {
			errorMsg = "DB接続エラーの為、注文内容詳細処理は行えませんでした。";
			request.setAttribute("nextPage", "login");
		}catch(Exception e){
			errorMsg ="予期せぬエラーが発生しました。<br>"+e; 
			request.setAttribute("nextPage", "login");
		} finally {
			
			if (!errorMsg.equals("")) {
			
				request.setAttribute("error", errorMsg);
				//error.jspにフォワード
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			} else {
				//orderDetail.jspへフォワード
				request.getRequestDispatcher("/view/orderDetail.jsp").forward(request, response);
			}
	
		}
	}
}
