package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Login;
import bean.Order;
import bean.User;
import dao.DetailDAO;
import dao.OrderDAO;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/orderedItem")
public class OrderedItemServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String errorMsg = "";
		String nextPage = "";
		
		try {
			//パラメータの取得
			String orderDate = (request.getParameter("orderDate"));
			String itemName = (request.getParameter("itemName"));
			String numberOfPieces = (request.getParameter("numberOfPieces"));
			String totalAmount = (request.getParameter("totalAmount"));
			
			//セッションからログインオブジェクトを取得
			HttpSession session = request.getSession();
			Login logininfo = (Login)session.getAttribute("logininfo");
			//セッション切れ確認
			if(logininfo == null) {
				errorMsg = "セッション切れの為、注文できません。";
				nextPage = "logout";
				return;
			}
			
			//ログインID取得
			int loginId = logininfo.getLoginId();
			//ログインIDからユーザー情報取得
			UserDAO userDao = new UserDAO();
			User user = userDao.selectByLoginId(loginId);
			
			//OrderDAOオブジェクトの生成
			OrderDAO objOrderDao = new OrderDAO();
			
			//DetailDAOオブジェクトの生成
			DetailDAO objDetailDao = new DetailDAO();

			//画面からの入力情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");
			
			//関連メソッドを呼び出し、戻り値としてOrderオブジェクトのリストを取得する
			ArrayList<Order> orderList = objOrderDao.selectByUserId(user.getUserId());
			
			//orderListをリクエストスコープに"order_list"という名前で格納する
			request.setAttribute("order_list", orderList);
			
		//DB接続エラーの場合
		} catch (IllegalStateException e) {
			errorMsg = "DB接続エラーの為、更新処理は行えませんでした。";

		} finally {
			//エラーなし
			if (errorMsg == null) {
				//userMenu.jspへフォワード
				request.getRequestDispatcher("/view/userMenu.jsp").forward(request, response);

			//エラーあり
			} else {
				//errorMsgをリクエストスコープに"error"という名前で格納する
				request.setAttribute("error", errorMsg);
				//error.jspにフォワード
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}
	}
}
