package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Login;
import bean.OrderedItem;
import bean.User;
import dao.OrderedItemDAO;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/orderedItem")
public class OrderedItemServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String errorMsg = "";
		String nextPage = "";
		
		try {
			
			//セッションからログインオブジェクトを取得
			HttpSession session = request.getSession();
			Login logininfo = (Login)session.getAttribute("logininfo");
			//セッション切れ確認
			if(logininfo == null) {
				errorMsg = "セッション切れの為、履歴表示はできません。";
				nextPage = "login";
				return;
			}
			
			//ログインID取得
			int loginId = logininfo.getLoginId();
			//ログインIDからユーザー情報取得
			UserDAO userDao = new UserDAO();
			User user = userDao.selectByLoginId(loginId);
			
			//OrderedItemDAOオブジェクトの生成
			OrderedItemDAO objOrderedItemDao = new OrderedItemDAO();
			
			//関連メソッドを呼び出し、戻り値としてOrderオブジェクトのリストを取得する
			ArrayList<OrderedItem> orderList = objOrderedItemDao.selectByUserId(user.getUserId());
			
			//orderListをリクエストスコープに"order_list"という名前で格納する
			request.setAttribute("order_list", orderList);
		
		}catch(UnsupportedOperationException e) {
			errorMsg = "クエリ発行に失敗しました。";
			nextPage = "login";
		//DB接続エラーの場合
		} catch (IllegalStateException e) {
			errorMsg = "DB接続エラーの為、履歴表示は行えませんでした。";
			nextPage = "login";
		} finally {
			//エラーなし
			if (errorMsg.equals("")) {
				//userMenu.jspへフォワード
				request.getRequestDispatcher("/view/orderedItem.jsp").forward(request, response);

			//エラーあり
			} else {
				//errorMsgをリクエストスコープに"errorMsg"という名前で格納する
				request.setAttribute("errorMsg", errorMsg);
				request.setAttribute("nextPage", nextPage);
				//error.jspにフォワード
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}
	}
}
