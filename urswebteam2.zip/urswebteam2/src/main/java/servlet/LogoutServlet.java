package servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//エラーメッセージ用変数、cmd情報
				String error = "";
				String cmd = "";
				
		try {
			//セッション情報クリア
			HttpSession session = request.getSession();
			session.invalidate();
			
		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、ログアウトは出来ません。";
			cmd = "menu";
			
		}finally {
			if(error.equals("")) {
				//login.jspにフォワード
				request.getRequestDispatcher("/view/login.jsp").forward(request, response);
			}else {
				//エラーメッセージを持ってerror.jspへフォワード
				request.setAttribute("cmd", cmd);
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
			
		}
	}

}
