package servlet;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import bean.Item;
import dao.ItemDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;


@WebServlet("/insertItem")
@MultipartConfig
public class InsertItemServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//エラーメッセージ用変数、cmd
		String errorMsg = "";
		String nextPage = "";
		
		try {
			
			//DAOクラスのオブジェクト生成
			ItemDAO itemDao = new ItemDAO();
			
			//登録する商品情報を格納するItemオブジェクト生成
			Item item = new Item();
			
			//画面からの入力情報受け取る
			String itemName = request.getParameter("name");
			String price = request.getParameter("price");
			String stockQuantity = request.getParameter("stockQuantity");
			String itemDetail = request.getParameter("itemDetail");
			
			//入力チェック
			if(itemName.equals("") || itemName == null) {
				errorMsg = "商品名が未入力の為、商品登録処理は行えませんでした。";
				nextPage = "list";
				return;
			}
			
			//重複チェック
			if(!itemDao.selectByItemName(itemName).getItemName().equals("")) { 
				errorMsg = "入力商品は既に登録済みの為、商品登録処理は行えませんでした。";
				nextPage = "list";
				return;
			}
			
			item.setItemName(itemName);
			item.setPrice(Integer.parseInt(price));
			item.setStock(Integer.parseInt(stockQuantity));
			item.setItemDetail(itemDetail);
			
			//ファイル取得用の情報を受け取る
			Part filePart = request.getPart("photoFile");
			String uploadDir = "";
			String filePath = "";
			String fileName = "";
			
			//写真登録
			if (filePart.getSize() != 0) {
				String contentDisposition = filePart.getHeader("content-disposition");
				Pattern pattern = Pattern.compile("filename=\"(.*)\"");
				Matcher matcher = pattern.matcher(contentDisposition);
				//抽出したファイル名が存在していれば抽出、なければ空白
				if (matcher.find()) {
					fileName = matcher.group(1);					
				}else {
					fileName = "";
				}
				
				File file_name = new File(fileName);
				
				//写真のファイル名をセット
				item.setPhotoFile(file_name.getName());
				
				// ファイル保存先のディレクトリ
				uploadDir = getServletContext().getRealPath("/file").replace("\\", "/");
				//アップロード先のフォルダがなければ作成
				File uploadDirectory = new File(uploadDir);
				if (!uploadDirectory.exists()) {
					uploadDirectory.mkdirs();
				}
				
				// ファイルを指定されたディレクトリに保存
				// （具体的には以下の階層に保存される）
				// C:\ usr\kis_java_pkg_2023\workspace\.metadata\.plugins\org.eclipse.wst.server.core\tmp0\wtpwebapps 
				filePath = uploadDir + "/" + file_name.getName();
				try (InputStream inputStream = filePart.getInputStream()) {
					Files.copy(inputStream, new File(filePath).toPath(),StandardCopyOption.REPLACE_EXISTING);
				}
			}
			
			//insert()メソッド呼び出し
			itemDao.insert(item);
			
		}catch(NumberFormatException e) {
			errorMsg = "価格または個数が不正です。正しい値を入力してください。";
			nextPage = "list";
			
		}catch(UnsupportedOperationException e) {
			errorMsg = "クエリ発行に失敗しました。";
			nextPage = "login";
		}catch(IllegalStateException e) {
			errorMsg= "DB接続エラーの為、商品登録処理は行えませんでした。";
			nextPage = "login";
		}finally {
			if(errorMsg.equals("")) {
				//itemListへフォワード
				request.getRequestDispatcher("/itemList").forward(request, response);
			}else {
			//エラーメッセージ、cmd情報を持ってerror.jspへフォワード
			request.setAttribute("errorMsg", errorMsg);
			request.setAttribute("nextPage", nextPage);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
		
	}
}
