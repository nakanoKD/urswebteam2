package servlet;

import java.io.IOException;

import bean.Item;
import dao.ItemDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/insertItem")
public class InsertItemServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//エラーメッセージ用変数、cmd
		String errorMsg = "";
		String nextPage = "";
		
		try {
			
			//DAOクラスのオブジェクト生成
			ItemDAO itemDao = new ItemDAO();
			
			//登録する商品情報を格納するItemオブジェクト生成
			Item item = new Item();
			
			//画面からの入力情報受け取る
			String itemName = request.getParameter("name");
			int price = Integer.parseInt(request.getParameter("price"));
			int stockQuantity = Integer.parseInt(request.getParameter("stockQuantity"));
			String itemDetail = request.getParameter("itemDetail");
			
			//入力チェック
			if(itemName.equals("") || itemName == null) {
				errorMsg = "商品名が未入力の為、商品登録処理は行えませんでした。";
				nextPage = "list";
				return;
			}
			if(itemDao.selectByItemName(itemName).getItemName().equals("")) { 
				//重複チェック
				errorMsg = "入力商品は既に登録済みの為、商品登録処理は行えませんでした。";
				nextPage = "list";
				return;
			}
			item.setItemName(itemName);
			
			//入力チェック
			if(price == 0) {
				errorMsg = "価格が未入力の為、商品登録処理は行えませんでした。";
				nextPage = "list";
				return;
			}
			item.setPrice(price);
			
			//入力チェック
			if(stockQuantity == 0) {
				errorMsg = "個数が未入力の為、商品登録処理は行えませんでした。";
				nextPage = "list";
				return;
			}
			
			//insert()メソッド呼び出し
			itemDao.insert(item);
			
		}catch(NumberFormatException e) {
			errorMsg = "価格または個数が不正です。整数値を入力してください。";
			nextPage = "menu";
			
		}catch(UnsupportedOperationException e) {
			errorMsg = "クエリ発行に失敗しました。";
			nextPage = "logout";
		}catch(IllegalStateException e) {
			errorMsg= "DB接続エラーの為、商品登録処理は行えませんでした。";
			nextPage = "logout";
		}finally {
			if(errorMsg.equals("")) {
				//ListServletへフォワード
				request.getRequestDispatcher("/list").forward(request, response);
			}else {
			//エラーメッセージ、cmd情報を持ってerror.jspへフォワード
			request.setAttribute("errorMsg", errorMsg);
			request.setAttribute("nextPage", nextPage);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
		
	}
}
