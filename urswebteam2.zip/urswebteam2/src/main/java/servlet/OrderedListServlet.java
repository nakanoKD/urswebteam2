package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Order;
import bean.User;
import dao.OrderDAO;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/orderedList")
public class OrderedListServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{
	
		String errorMsg = "";
		 
		try{
			
			HttpSession session = request.getSession();
			
			//文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");
			
			// エラーチェック
			
			
			// エラーがあれば早期リターン
			if(!errorMsg.equals(""))return;
			
			// 注文情報リストを取得
			OrderDAO orderDao = new OrderDAO();
			ArrayList<Order> orderList = orderDao.selectAll();
			
			// ユーザ名リストを取得
			ArrayList<String> userNameList = new ArrayList<String>();
			UserDAO userDao = new UserDAO();
			for(int i = 0; i < orderList.size(); i++){
				User user = userDao.selectByUserId(orderList.get(i).getUserId());
				userNameList.add(user.getLastname() + user.getFirstname());
			}
			
			// スコープに格納
			request.setAttribute("orderList", orderList);
			request.setAttribute("userNameList", userNameList);
			
		}catch (IllegalStateException e) {
			errorMsg ="DB接続エラーの為、購入は出来ません。 ";
			request.setAttribute("cmd", "logout");
		}catch(Exception e){
			errorMsg ="予期せぬエラーが発生しました。<br>"+e; 
			request.setAttribute("cmd", "logout");
		}finally{
			// エラー画面へフォワード
 			if(!errorMsg.equals("")) {
 				request.setAttribute("errorMsg", errorMsg);
 				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
 				return;
 			}
 			
 			// メニュー画面へフォワード
			request.getRequestDispatcher("/view/orderedList.jsp").forward(request, response);
		}
		
	}
}
