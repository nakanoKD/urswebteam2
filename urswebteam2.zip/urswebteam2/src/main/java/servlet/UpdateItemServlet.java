package servlet;

import java.io.IOException;

import bean.Item;
import dao.ItemDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/updateItem")
public class UpdateItemServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//エラーの変数を定義
		String errorMsg = "";
		//cmdの定義
		String cmd = "";

		try {
			//画面からの入力情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");

			//各情報の取得
			String item_name = request.getParameter("item_name");
			String price = request.getParameter("price");
			String stock = request.getParameter("stock");

			//DAOオブジェクトの生成
			ItemDAO itemDao = new ItemDAO();

			//TITLEが未入力の場合の条件分岐
			if (item_name.equals("")) {
				errorMsg = "商品名が未入力の為、商品更新処理は行えませんでした。";
				return;
			}

			//価格が未入力の場合の条件分岐
			if (price.equals("")) {
				errorMsg = "価格が未入力の為、商品更新処理は行えませんでした。";
				return;
			}
			
			//Itemオブジェクトの生成
			Item item = itemDao.selectByItemName(item_name);
				
			//存在のチェック
			if (item.getItemName() == null) {
				errorMsg = "更新対象の商品が存在しない為、商品更新処理は行えませんでした。";
				cmd = "menu";
				return;
			}
			
			//Bookオブジェクトに格納
			item.setItemName(item_name);
			item.setStock(Integer.parseInt(stock));
			item.setPrice(Integer.parseInt(price));

			//BookDAOのupdate（）メソッドを利用
			itemDao.update(item);

		} catch (NumberFormatException e) {
			//価格が数値以外のエラー
			errorMsg = "価格の値が不正の為、商品更新処理は行えませんでした。";
		} catch (UnsupportedOperationException e) {
			errorMsg = "クエリ発行に失敗しました。";
			cmd = "logout";
		} catch (IllegalStateException e) {
			errorMsg = "DB接続エラーの為、商品更新処理は行えませんでした。";
			cmd = "logout";
		} finally {

			//遷移先をif文で分岐
			if (errorMsg.equals("")) {
				//ListServletへフォワード
				request.getRequestDispatcher("/itemList").forward(request, response);
			} else {
				//cmdの情報とエラーの情報をerror.jspにフォワード
				request.setAttribute("errorMsg", errorMsg);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
