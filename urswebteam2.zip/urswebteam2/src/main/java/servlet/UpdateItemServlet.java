package servlet;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import bean.Item;
import dao.ItemDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@WebServlet("/updateItem")
@MultipartConfig
public class UpdateItemServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//エラーの変数を定義
		String errorMsg = "";
		//cmdの定義
		String cmd = "";

		try {
			// 画面からの入力情報を受け取るためのエンコードを設定
			request.setCharacterEncoding("UTF-8");

			// 各情報の取得
			String itemId = request.getParameter("itemId");
			String itemName = request.getParameter("itemName");
			String price = request.getParameter("price");
			String stock = request.getParameter("stock");
			String itemDetail = request.getParameter("itemDetail");

			// DAOオブジェクトの生成
			ItemDAO itemDao = new ItemDAO();
			
			// 商品を取得
			Item item = itemDao.selectByItemId(Integer.parseInt((itemId)));
			
			// 存在のチェック
			if (item == null) {
				errorMsg = "更新対象の商品が存在しない為、商品更新処理は行えませんでした。";
				cmd = "menu";
				return;
			}
			
			// 名前が未入力ではない場合の条件分岐
			if (!itemName.equals("")) {
				item.setItemName(itemName);
			}

			// 価格が未入力ではない場合の条件分岐
			if (!price.equals("")) {
				item.setPrice(Integer.parseInt(price));
			}
			
			// 在庫が未入力ではない場合の条件分岐
			if (!stock.equals("")) {
				item.setStock(Integer.parseInt(stock));
			}
			
			// 商品詳細が未入力ではない場合の条件分岐
			if (!itemDetail.equals("")) {
				item.setItemDetail(itemDetail);
			}
			
			//ファイル取得用の情報を受け取る
			Part filePart = request.getPart("photoFile");
			String uploadDir = "";
			String filePath = "";
			String fileName = "";
			
			//写真登録
			if (filePart.getSize() != 0) {
				String contentDisposition = filePart.getHeader("content-disposition");
				Pattern pattern = Pattern.compile("filename=\"(.*)\"");
				Matcher matcher = pattern.matcher(contentDisposition);
				//抽出したファイル名が存在していれば抽出、なければ空白
				if (matcher.find()) {
					fileName = matcher.group(1);					
				}else {
					fileName = "";
				}
				
				File file_name = new File(fileName);
				
				//写真のファイル名をセット
				item.setPhotoFile(file_name.getName());
				
				// ファイル保存先のディレクトリ
				uploadDir = getServletContext().getRealPath("/file").replace("\\", "/");
				//アップロード先のフォルダがなければ作成
				File uploadDirectory = new File(uploadDir);
				if (!uploadDirectory.exists()) {
					uploadDirectory.mkdirs();
				}
				
				// ファイルを指定されたディレクトリに保存
				// （具体的には以下の階層に保存される）
				// C:\ usr\kis_java_pkg_2023\workspace\.metadata\.plugins\org.eclipse.wst.server.core\tmp0\wtpwebapps 
				filePath = uploadDir + "/" + file_name.getName();
				try (InputStream inputStream = filePart.getInputStream()) {
					Files.copy(inputStream, new File(filePath).toPath(),StandardCopyOption.REPLACE_EXISTING);
				}
			}
			
			// ItemDAOのupdate（）メソッドを利用
			itemDao.update(item);
			
		} catch (NumberFormatException e) {
			//価格が数値以外のエラー
			errorMsg = "価格の値が不正の為、商品更新処理は行えませんでした。";
		} catch (UnsupportedOperationException e) {
			errorMsg = "クエリ発行に失敗しました。";
			cmd = "login";
		} catch (IllegalStateException e) {
			errorMsg = "DB接続エラーの為、商品更新処理は行えませんでした。";
			cmd = "login";
		} finally {

			//遷移先をif文で分岐
			if (errorMsg.equals("")) {
				//ListServletへフォワード
				request.getRequestDispatcher("/itemList").forward(request, response);
			} else {
				//cmdの情報とエラーの情報をerror.jspにフォワード
				request.setAttribute("errorMsg", errorMsg);
				request.setAttribute("nextPage", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
