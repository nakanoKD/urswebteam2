package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Item;
import bean.Login;
import bean.OrderedItem;
import bean.User;
import dao.ItemDAO;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/order")
public class OrderServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//エラーメッセージ用変数、cmd情報
		String errorMsg = "";
		String nextPage = "";

		int loginId;
		int userId;
		String email;
		String lastname;
		String lastnameRuby;
		String firstname;
		String firstnameRuby;
		String sex;
		String postalcode;
		String prefecture;
		String city;
		String itemName;
		int itemId;
		int price;
		int quantity;
		String note;

		try {

			//セッションからログインオブジェクトを取得
			HttpSession session = request.getSession();
			Login logininfo = (Login) session.getAttribute("logininfo");

			//セッション切れ確認
			if (logininfo == null) {
				errorMsg = "セッション切れの為、注文できません。";
				nextPage = "login";
				return;
			}

			//ログインID取得
			loginId = logininfo.getLoginId();

			//画面からのデータを受け取る
			email = request.getParameter("email");
			lastname = request.getParameter("lastname");
			lastnameRuby = request.getParameter("lastnameRuby");
			firstname = request.getParameter("firstname");
			firstnameRuby = request.getParameter("firstnameRuby");
			sex = request.getParameter("sex");
			postalcode = request.getParameter("postalcode");
			prefecture = request.getParameter("prefecture");
			city = request.getParameter("city");
			itemName = request.getParameter("itemName");
			quantity = Integer.parseInt(request.getParameter("quantity"));
			note = request.getParameter("note");

			//ログインIDからユーザー情報取得
			UserDAO userDao = new UserDAO();
			User user = userDao.selectByLoginId(loginId);

			//ユーザー情報が無ければ登録
			if (user.getUserId() == 0) {
				user.setLoginId(loginId);
				user.setEmail(email);
				user.setLastname(lastname);
				user.setLastnameRuby(lastnameRuby);
				user.setFirstname(firstname);
				user.setFirstnameRuby(firstnameRuby);
				user.setSex(sex);
				user.setPostalCode(postalcode);
				user.setPrefecture(prefecture);
				user.setCity(city);
				user.setDeleteFlg("1");
				user.setMemberShipFlg("1");
				userDao.insert(user);
			}

			//itemNameで商品情報を呼び出すメソッド呼び出し
			ItemDAO itemDao = new ItemDAO();
			Item item = itemDao.selectByItemName(itemName);
			price = item.getPrice();
			itemId = item.getItemId();

			//ユーザー情報
			User user2 = userDao.selectByLoginId(loginId);
			userId = user2.getUserId();

			//取得した情報をリクエストスコープへ登録
			request.setAttribute("item", item);
			request.setAttribute("quantity", quantity);

			//値をセット
			//オブジェクト生成
			OrderedItem orderedItem = new OrderedItem();
			orderedItem.setUserId(userId);
			orderedItem.setItemName(itemName);
			orderedItem.setQuantity(quantity);
			orderedItem.setPrice(price);
			orderedItem.setFirstName(firstname);
			orderedItem.setLastName(lastname);
			orderedItem.setNote(note);

			//セッションからordered_listの配列を取得
			ArrayList<OrderedItem> list = (ArrayList<OrderedItem>) session.getAttribute("order_list");

			if (list == null) { //取得できなかった場合、新規配列作成
				list = new ArrayList<OrderedItem>();
			}

			//order_list内に今回購入しようとしている商品がないかチェック
			if (list.contains(orderedItem)) {
				//購入数のみをカート情報に加算
				list.set(list.indexOf(orderedItem), orderedItem);
			} else {
				//OrderオブジェクトをList配列に追加
				list.add(orderedItem);
			}

			//セッションスコープへ登録
			session.setAttribute("order_list", list);

		} catch (NumberFormatException e) {
			errorMsg = "個数の値が不正です。整数値を入力してください。";
			nextPage = "menu";

		} catch (UnsupportedOperationException e) {
			errorMsg = "クエリ発行に失敗しました。";
			nextPage = "logout";
		} catch (IllegalStateException e) {
			//エラーメッセージ設定
			errorMsg = "DB接続エラーの為、カートに追加は出来ません。";
			nextPage = "logout";
		} finally {
			if (errorMsg.equals("")) {
				//showCartへフォワード
				request.getRequestDispatcher("/showCart").forward(request, response);
			} else {
				//エラーメッセージを持ってerror.jspへフォワード
				request.setAttribute("errorMsg", errorMsg);
				request.setAttribute("nextPage", nextPage);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}

}
