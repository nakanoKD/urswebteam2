package servlet;

import java.io.IOException;

import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/deleteUser")
public class deleteUserServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//エラーメッセージ用変数、cmd情報
		String error = "";
		String cmd = "";
		
		try {
			//ユーザーIDの入力パラメータを取得
			String userId = request.getParameter("userId");
			
			//UserDAOをインスタンス化し、関連メソッド(ユーザー削除処理)を呼び出す
			UserDAO userDao = new UserDAO();
			userDao.delete(userId);
			
		}catch(UnsupportedOperationException e) {
			error = "クエリ発行に失敗しました。";
			cmd = "logout";
		}catch(IllegalStateException e) {
			//エラーメッセージ設定
			error = "DB接続エラーの為、ユーザー削除は行えません。";
			cmd = "logout";
			
		}finally {
			if(error.equals("")) {
				//ListUserServletへフォワード
				request.getRequestDispatcher("/listUser").forward(request, response);
			}else {
				//エラーメッセージを持ってerror.jspへフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}	
		}
	}

}
