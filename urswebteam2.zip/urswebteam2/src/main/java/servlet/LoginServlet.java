/*
 * ユニフォーム予約管理システム
 * 幕内日湖
 * 2024/6/18
 */

package servlet;

import java.io.IOException;

import bean.Login;
import dao.LoginDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//エラーメッセージ用変数、cmd情報
		String error = "";
		String cmd = "";
				
		//画面からのデータを受け取る
		String loginName = request.getParameter("loginName");
		String password = request.getParameter("password");
		
		try {
			
			//loginDAOのオブジェクト生成
			LoginDAO loginDao = new LoginDAO();
			
			//selectByLoginName呼び出し, データベースからログイン情報を受け取る
			Login logininfo = loginDao.selectByLoginName(loginName, password);
			
			if(logininfo == null) {
				//エラーメッセージ設定
				error = "入力データが間違っています。";
				cmd = "login";
				return;
			}
			
			//取得した情報をセッションスコープへ登録
			HttpSession session = request.getSession();
			session.setAttribute("logininfo", logininfo);
			
			//クッキーに入力情報のloginNameとpasswordを登録
			Cookie cookieId = new Cookie("loginName",loginName);
			cookieId.setMaxAge(60 * 60 * 24 * 5);
			response.addCookie(cookieId);
			Cookie cookiePass = new Cookie("password",password);
			cookiePass.setMaxAge(60 * 60 * 24 * 5);
			response.addCookie(cookiePass);
			
		}catch(UnsupportedOperationException e) {
			error = "クエリ発行に失敗しました。";
			cmd = "login";
		}catch(IllegalStateException e) {
			//エラーメッセージ設定
			error = "DB接続エラーの為、ログインは出来ません。";
			cmd = "login";
			
		}finally {
			if(error.equals("")) {
				//menu.jspにフォワード
				request.getRequestDispatcher("/view/menu.jsp").forward(request, response);
			}else {
				if(cmd.equals("login")) {
					//login.jspにフォワード
					request.setAttribute("error", error);
					request.getRequestDispatcher("/view/login.jsp").forward(request, response);
				}else {
					//error.jspにフォワード
					request.setAttribute("error", error);
					request.setAttribute("cmd", cmd);
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}
			}
		}
	}
}
