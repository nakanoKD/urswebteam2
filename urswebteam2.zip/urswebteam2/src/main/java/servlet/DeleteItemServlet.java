package servlet;

import java.io.IOException;

import dao.ItemDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/deleteItem")
public class DeleteItemServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//エラーメッセージ用変数、cmd情報
		String errorMsg = "";
		String nextPage = "";

		//ItemDAOをオブジェクト化
		ItemDAO objDao = new ItemDAO();

		try {

			//画面からの入力情報受け取る
			request.setCharacterEncoding("UTF-8");

			String itemId = request.getParameter("itemId");
			//入力チェック
			if (itemId.equals("")) {
				errorMsg = "商品削除処理は行えませんでした。";
				nextPage = "list";
				return;
			}

			//delete()メソッド呼び出し
			objDao.setDelete(Integer.parseInt(itemId));

		}catch(UnsupportedOperationException e) {
			errorMsg = "クエリ発行に失敗しました。";
			nextPage = "login";
		} catch (IllegalStateException e) {
			errorMsg = "DB接続エラーの為、削除処理は行えませんでした。";
			nextPage = "login";
			
		}finally {
			if(errorMsg.equals("")) {
				//itemListServletへフォワード
				request.getRequestDispatcher("/itemList").forward(request, response);
			}else {
				//エラーメッセージを持ってerror.jspへフォワード
				request.setAttribute("errorMsg", errorMsg);
				request.setAttribute("cmd", nextPage);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
			
		}

	}
}
