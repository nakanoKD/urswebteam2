package servlet;

import java.io.IOException;

import bean.Login;
import bean.User;
import dao.LoginDAO;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/insertUser")
public class InsertUserServlet extends HttpServlet {

	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{
		
		String errorMsg = "";
		
		try{
			
			//文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");
			
			enum kore{
				
			}
			
			//パラメータの取得
			String loginName = request.getParameter("loginName");
			String password = request.getParameter("password");
			String email = request.getParameter("email");
			String lastname = request.getParameter("lastname");
			String firstname = request.getParameter("firstname");
			String lastnameRuby = request.getParameter("lastnameRuby");
			String firstnameRuby = request.getParameter("firstnameRuby");
			String sex = request.getParameter("sex");
			String postalCode = request.getParameter("postalCode");
			String prefecture = request.getParameter("prefecture");
			String city = request.getParameter("city");
		
			// エラーチェック
			if(loginName.equals(""))errorMsg += "ユーザーネームが未入力";
			if(password.equals(""))errorMsg += " パスワードが未入力";
			if(email.equals(""))errorMsg += " メールアドレスが未入力";
			if(lastname.equals(""))errorMsg += " 名字が未入力";
			if(firstname.equals(""))errorMsg += " 名前が未入力";
			if(lastnameRuby.equals(""))errorMsg += " 名字が未入力";
			if(firstnameRuby.equals(""))errorMsg += " 名前が未入力";
			if(postalCode.equals(""))errorMsg += " 郵便番号が未入力";
			if(prefecture.equals(""))errorMsg += " 都道府県が未選択";
			if(city.equals(""))errorMsg += " 住所が未入力";
			for (int i = 0; i < postalCode.length(); i++) {
				if(i == 3)continue;
				if (Character.isDigit(postalCode.charAt(i))) {
					continue;
				} else {
					errorMsg += " 郵便番号の値が不正";
					break;
				}
			}
			
			// エラーの場合は処理終了
			if(!errorMsg.equals("")) {
				errorMsg += "の為、会員登録が行えませんでした。";
				request.setAttribute("nextPage", "insertUser");
				return;
			}
			
			// 1件のbeanにまとめ、登録DAO実行
			
			// ログイン情報
			LoginDAO loginDao = new LoginDAO();
			Login login = new Login();
			login.setLoginName(loginName);
			login.setPassword(password);
			login.setManagerOrUserFlag("1");
			login.setAvailableAccountFlag("1");
			loginDao.insert(login);
			
			// ログインIDが生成されたものを新たに入手
			login = loginDao.selectByLoginName(
					loginName, password);
			
			//セッションのログイン情報更新
			HttpSession session = request.getSession();
			session.setAttribute("logininfo", login);
			
			// 会員情報
			UserDAO userDao = new UserDAO();
			User user = new User();
			user.setLoginId(login.getLoginId());
			user.setEmail(email);
			user.setLastname(lastname);
			user.setLastnameRuby(lastnameRuby);
			user.setFirstname(firstname);
			user.setFirstnameRuby(firstnameRuby);
			user.setSex(sex);
			user.setPostalCode(postalCode);
			user.setPrefecture(prefecture);
			user.setCity(city);
			user.setMemberShipFlg("1");
			userDao.insert(user);
			
		}catch (IllegalStateException e) {
			errorMsg ="DB接続エラーの為、会員登録は行えませんでした。";
			request.setAttribute("nextPage", "login");
		}catch(Exception e){
			errorMsg ="予期せぬエラーが発生しました。<br>"+e;
			request.setAttribute("nextPage", "login");
		}finally{
			// エラー画面へフォワード
 			if(!errorMsg.equals("")) {
 				request.setAttribute("errorMsg", errorMsg);
 				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
 				return;
 			}
 			
 			// 商品一覧へフォワード
			request.getRequestDispatcher("/itemList").forward(request, response);
		}
	}
}
