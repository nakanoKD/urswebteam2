package servlet;
import java.io.IOException;

import bean.Login;
import bean.Order;
import dao.OrderDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/updateFlag")
public class UpdateDateServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		//エラーの変数を定義
		String errorMsg = "";
		//cmdの定義
		String nextPage = "";
		
		try {
			
			//セッションからログインオブジェクトを取得
			HttpSession session = request.getSession();
			Login logininfo = (Login) session.getAttribute("logininfo");

			//セッション切れ確認
			if (logininfo == null) {
				errorMsg = "セッション切れの為、注文できません。";
				nextPage = "login";
				return;
			}

			
		//画面からの入力情報を受け取るためのエンコードを設定
		request.setCharacterEncoding("UTF-8");
		
		//入金日と発送日の入力パラメータの取得
		String paymentDate = request.getParameter("paymentDate");
		String shippingDate = request.getParameter("shippingDate");
		int orderId = Integer.parseInt(request.getParameter("orderId"));
		
		//オブジェクトの生成
		OrderDAO orderDao = new OrderDAO();
		Order order = orderDao.selectByOrderId(orderId);
							
		//orderオブジェクトに格納
		order.setPaymentDate(paymentDate);
		order.setShippingDate(shippingDate);
		
		//OrderDAOのupdateFlg（）メソッドを利用
		orderDao.updateFlg(order);
		
		} catch (UnsupportedOperationException e) {
		errorMsg = "クエリ発行に失敗しました。";
		nextPage = "login";
		} catch (IllegalStateException e) {
		errorMsg = "DB接続エラーの為、日時の更新処理は行えませんでした。";
		nextPage = "login";
		
		} finally {
		//遷移先を分岐
		if (errorMsg.equals("")) {
		//ListServletへフォワード
		request.getRequestDispatcher("/orderedList").forward(request, response);
		} else {
		//cmdの情報とエラーの情報をerror.jspにフォワード
		request.setAttribute("errorMsg", errorMsg);
		request.setAttribute("nextPage", nextPage);
		request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		}
	}
	}
}
