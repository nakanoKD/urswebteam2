package servlet;
import java.io.IOException;

import bean.Order;
import dao.OrderDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/updateFlag")
public class UpdateDateServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		//エラーの変数を定義
		String errorMsg = "";
		//cmdの定義
		String cmd = "";
		
		try {
		//画面からの入力情報を受け取るためのエンコードを設定
		request.setCharacterEncoding("UTF-8");
		
		//入金日と発送日の入力パラメータの取得
		String paymentDate = request.getParameter("payment_date");
		String shippingDate = request.getParameter("shipping_date");
		String orderId = request.getParameter("orderId");
		
		//オブジェクトの生成
		Order order = new Order();
		OrderDAO orderDao = new OrderDAO();
							
		//orderオブジェクトに格納
		order = orderDao.selectByOrderId(Integer.parseInt(orderId));
		order.setPaymentDate(paymentDate);
		order.setShippingDate(shippingDate);
		
		//OrderDAOのupdate（）メソッドを利用
		orderDao.update(order);
		
		} catch (UnsupportedOperationException e) {
		errorMsg = "クエリ発行に失敗しました。";
		cmd = "logout";
		} catch (IllegalStateException e) {
		errorMsg = "DB接続エラーの為、日時の更新処理は行えませんでした。";
		cmd = "logout";
		
		} finally {
		//遷移先を分岐
		if (errorMsg.equals("")) {
		//ListServletへフォワード
		request.getRequestDispatcher("orderedList").forward(request, response);
		} else {
		//cmdの情報とエラーの情報をerror.jspにフォワード
		request.setAttribute("errorMsg", errorMsg);
		request.setAttribute("cmd", cmd);
		request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		}
	}
	}
}
