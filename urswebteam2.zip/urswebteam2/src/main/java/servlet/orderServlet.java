package servlet;

import java.io.IOException;
import java.util.ArrayList;

import bean.Item;
import bean.Login;
import bean.OrderedItem;
import bean.User;
import dao.ItemDAO;
import dao.OrderedItemDAO;
import dao.detailDAO;
import dao.userDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/order")
public class orderServlet extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//エラーメッセージ用変数、cmd情報
		String error = "";
		String cmd = "";

		int loginId;
		int userId;
		String email;
		String lastname;
		String lastnameRuby;
		String firstname;
		String firstnameRuby;
		String sex;
		String postalcode;
		String prefecture;
		String city;
		String itemName;
		int itemId;
		int price;
		int detailId;
		int quantity;
		String note;

		try {

			//セッションからログインオブジェクトを取得
			HttpSession session = request.getSession();
			Login logininfo = (Login) session.getAttribute("logininfo");

			//セッション切れ確認
			if (logininfo == null) {
				error = "セッション切れの為、注文できません。";
				cmd = "logout";
				return;
			}

			//ログインID取得
			loginId = logininfo.getLoginId();

			//画面からのデータを受け取る
			email = request.getParameter("email");
			lastname = request.getParameter("lastname");
			lastnameRuby = request.getParameter("lastnameRuby");
			firstname = request.getParameter("firstname");
			firstnameRuby = request.getParameter("firstnameRuby");
			sex = request.getParameter("sex");
			postalcode = request.getParameter("postalcode");
			prefecture = request.getParameter("prefecture");
			city = request.getParameter("city");
			itemName = request.getParameter("itemName");
			quantity = Integer.parseInt(request.getParameter("quantity"));
			note = request.getParameter("note");

			//ログインIDからユーザー情報取得
			userDAO userDao = new userDAO();
			User user = userDao.selectByLoginId(loginId);

			//ユーザー情報が無ければ登録
			if (user == null) {
				user.setLoginId(loginId);
				user.setEmail(email);
				user.setLastName(lastname);
				user.setLastNameRuby(lastnameRuby);
				user.setFirstName(firstname);
				user.setFirstNameRuby(firstnameRuby);
				user.setSex(sex);
				user.setPostalCode(postalcode);
				user.setPrefecture(prefecture);
				user.setCity(city);
				user.setDeleteFlg("1");
				user.setMemberShipFlg("1");
				userDao.insert(user);
			}

			//itemNameで商品情報を呼び出すメソッド呼び出し
			ItemDAO itemDao = new ItemDAO();
			Item item = itemDao.selectByItemName(itemName);
			price = item.getPrice();
			itemId = item.getItemId();
			
			//ユーザー情報
			userId = user.getUserId();
			detailDAO detailDao = new detailDAO();

			//取得した情報をリクエストスコープへ登録
			request.setAttribute("item", item);
			request.setAttribute("quantity", quantity);

			//DAOクラスからメソッドを呼び出し、値をセット
			OrderedItemDAO orderedItemDao = new OrderedItemDAO();
			//オブジェクト生成
			OrderedItem orderedItem = new OrderedItem();
			orderedItem.setUserName();
			orderedItem.setItemName();
			orderedItem.setQuantity();
			orderedItem.setPrice();
			orderedItem.setFirstName();
			orderedItem.setLastName();

			//セッションからordered_listの配列を取得
			ArrayList<OrderedItem> list = (ArrayList<OrderedItem>) session.getAttribute("order_list");

			if (list == null) { //取得できなかった場合、新規配列作成
				list = new ArrayList<OrderedItem>();
			}

			//order_list内に今回購入しようとしている商品がないかチェック
			if (list.contains(orderedItem)) {
				//購入数のみをカート情報に加算
				list.set(list.indexOf(orderedItem), orderedItem);
			} else {
				//OrderオブジェクトをList配列に追加
				list.add(orderedItem);
			}

			//セッションスコープへ登録
			session.setAttribute("order_list", list);

		} catch (NumberFormatException e) {
			error = "個数の値が不正です。整数値を入力してください。";
			cmd = "menu";

		} catch (UnsupportedOperationException e) {
			error = "クエリ発行に失敗しました。";
			cmd = "logout";
		} catch (IllegalStateException e) {
			//エラーメッセージ設定
			error = "DB接続エラーの為、カートに追加は出来ません。";
			cmd = "logout";
		} finally {
			if (error.equals("")) {
				//showCartへフォワード
				request.getRequestDispatcher("/showCart").forward(request, response);
			} else {
				//エラーメッセージを持ってerror.jspへフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}

}
