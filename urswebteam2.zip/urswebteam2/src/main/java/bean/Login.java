package bean;

public class Login {

	//変数定義

	private int loginId;

	private String loginName;

	private String password;

	private String managerOrUserFlag;

	private String availableAccountFlag;

	private String membershipFlag;

	//コンストラクタ
	public Login() {
		loginId = 0;
		loginName = "";
		password = "";
		managerOrUserFlag = "";
		availableAccountFlag = "";
		membershipFlag = "";
	}

	//各変数のアクセサメソッド

	public int getLoginId() {
		return loginId;
	}

	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getManagerOrUserFlag() {
		return managerOrUserFlag;
	}

	public void setManagerOrUserFlag(String managerOrUserFlag) {
		this.managerOrUserFlag = managerOrUserFlag;
	}

	public String getAvailableAccountFlag() {
		return availableAccountFlag;
	}

	public void setAvailableAccountFlag(String availableAccountFlag) {
		this.availableAccountFlag = availableAccountFlag;
	}

	public String getMembershipFlag() {
		return membershipFlag;
	}

	public void setMembershipFlag(String membershipFlag) {
		this.membershipFlag = membershipFlag;
	}

}
