package bean;

public class Item {
	
	// 商品IDを格納する変数
	private int itemId;
	// 商品名を格納する変数
	private String itemName;
	// 値段を格納する変数
	private int price;
	// 在庫を格納する変数
	private int stock;
	// 商品詳細を格納する変数
	private String itemDetail;
	// 登録日を格納する変数
	private String insertDay;
	// 更新日を格納する変数
	private String updateDay;
	// 商品画像を格納する変数
	private String photoFile;
	
	// コンストラクタ
	public Item() {
		 itemId = 0;
		 itemName = "";
		 price = 0;
		 stock = 0;
		 itemDetail = "";
		 insertDay = "";
		 updateDay = "";
		 photoFile = "";
	}
	
	// 各変数のアクセサ=======================================
	// 商品IDのアクセサ
	public int getItemId() {
	    return itemId;
	}
	public void setItemId(int itemId) {
	    this.itemId = itemId;
	}

	// 商品名のアクセサ
	public String getItemName() {
	    return itemName;
	}
	public void setItemName(String itemName) {
	    this.itemName = itemName;
	}

	// 値段のアクセサ
	public int getPrice() {
	    return price;
	}
	public void setPrice(int price) {
	    this.price = price;
	}

	// 在庫のアクセサ
	public int getStock() {
	    return stock;
	}
	public void setStock(int stock) {
	    this.stock = stock;
	}

	// 商品詳細のアクセサ
	public String getItemDetail() {
	    return itemDetail;
	}
	public void setItemDetail(String itemDetail) {
	    this.itemDetail = itemDetail;
	}

	// 登録日のアクセサ
	public String getInsertDate() {
	    return insertDay;
	}
	public void setInsertDate(String insertDay) {
	    this.insertDay = insertDay;
	}

	// 更新日のアクセサ
	public String getUpdateDate() {
	    return updateDay;
	}
	public void setUpdateDate(String updateDay) {
	    this.updateDay = updateDay;
	}

	// 商品画像のアクセサ
	public String getPhotoFile() {
	    return photoFile;
	}
	public void setPhotoFile(String photoFile) {
	    this.photoFile = photoFile;
	}

}
