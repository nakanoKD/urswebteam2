package bean;

public class Detail {
	
	//変数定義
	
	private int detailId;
	
	private int orderId;
	
	private int itemId;
	
	private int numberOfPieces;
	

	
	//コンストラクタ
		public Detail() {
			detailId = 0;
			orderId = 0;
			itemId = 0;
			numberOfPieces = 0;
		}
	
		//アクセサメソッド

	public int getDetailId() {
		return detailId;
	}

	public void setDetailId(int detailId) {
		this.detailId = detailId;
	}

	
	
	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getNumberOfPieces() {
		return numberOfPieces;
	}

	public void setNumberOfPieces(int numberOfPieces) {
		this.numberOfPieces = numberOfPieces;
	}
	
	

}
