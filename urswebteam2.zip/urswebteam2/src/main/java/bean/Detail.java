package bean;

public class Detail {
	
	//変数定義
	
	private int detailId;
	
	private int itemId;
	
	private int numberOfPieces;
	
	private String itemName;
	
	private int price;
	
	//コンストラクタ
		public Detail() {
			detailId = 0;
			itemId = 0;
			numberOfPieces = 0;
		}
	
		//アクセサメソッド
		
	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}


	public int getDetailId() {
		return detailId;
	}

	public void setDetailId(int detailId) {
		this.detailId = detailId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getNumberOfPieces() {
		return numberOfPieces;
	}

	public void setNumberOfPieces(int numberOfPieces) {
		this.numberOfPieces = numberOfPieces;
	}
	
	

}
