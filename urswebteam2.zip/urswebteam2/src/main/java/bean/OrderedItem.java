package bean;

public class OrderedItem {

	private int userId;
	private String itemName;
	private int quantity;
	private String orderDate;
	private int price;
	private String firstName;
	private String lastName;
	
	//コンストラクタ生成
	public OrderedItem() {
		this.userId = 0;
		this.itemName = "";
		this.quantity = 0;
		this.orderDate = "";	
		this.price = 0;
		this.firstName = "";
		this.lastName = "";
	}
	
	
	public int getUserId() {
		return userId;
	}
	

	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	
}
