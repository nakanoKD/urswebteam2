package bean;

public class Sale {
	
	private int orderId;
	private int userId;
	private String itemName;
	private int price;
	private int numberOfPieces;
	
	public Sale() {
		this.orderId = 0;
		this.itemName = "";
		this.price = 0;
		this.numberOfPieces = 0;//個数
	}
	
	//引数ありコンストラクタ
	public Sale(Item item, int Quantity) {
		this.orderId = 0;
		this.itemName = item.getItemName();
		this.price = item.getPrice();
		this.numberOfPieces = Quantity;//個数
	}
	
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId= orderId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getNumberOfPieces() {
		return numberOfPieces;
	}
	public void setNumberOfPieces(int numberOfPieces) {
		this.numberOfPieces = numberOfPieces;
	}
		
	
	
}
