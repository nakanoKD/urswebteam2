package bean;

public class Administor {

	//管理者ユーザーIDを格納する変数
	private int managerId;
	//名字を格納する変数
	private String lastname;
	//名字(カナ)を格納する変数
	private String lastnameRuby;
	//名前を格納する変数
	private String firstname;
	//名前(カナ)を格納する変数
	private String firstnameRuby;
	//退会フラグを格納する変数
	private String deleteFlg;
	//登録日を格納する変数
	private String registrationDate;
	//更新日を格納する変数
	private String updateDate;

	//コンストラクタ
	public Administor() {
		this.managerId = 0;
		this.lastname = "";
		this.lastnameRuby = "";
		this.firstname = "";
		this.firstnameRuby = "";
		this.deleteFlg = "";
		this.registrationDate = "";
		this.updateDate = "";
	}

	/* getterメソッドの定型文 */ /* setterメソッドの定型文 */

	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getLastnameRuby() {
		return lastnameRuby;
	}

	public void setLastnameRuby(String lastnameRuby) {
		this.lastnameRuby = lastnameRuby;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getFirstnameRuby() {
		return firstnameRuby;
	}

	public void setFirstnameRuby(String firstnameRuby) {
		this.firstnameRuby = firstnameRuby;
	}

	public String getDeleteFlg() {
		return deleteFlg;
	}

	public void setDeleteFlg(String deleteFlg) {
		this.deleteFlg = deleteFlg;
	}

	public String getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

}
