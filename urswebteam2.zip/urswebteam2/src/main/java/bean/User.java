package bean;

/**
 * 会員情報をまとめたDTOクラス
 */
public class User {
	//フィールド変数の定義
	private int userId;//会員ID
	private int loginId;//ログインID
	private String email;//メールアドレス
	private String lastName;//名字
	private String lastNameRuby;//名字（カナ）
	private String firstName;//名前
	private String firstNameRuby;//名前（カナ）
	private String sex;//性別
	private String postalCode;//郵便番号
	private String prefecture;//住所（都道府県）
	private String city;//住所（市から番地）
	private String deleteFlg;//退会フラグ
	private String registrationDate;//登録日
	private String updateDate;//更新日
	private String deleteDate;//削除日
	private String memberShipFlg;//会員/非会員フラグ

	//コンストラクタ定義
	public User() {
		this.userId = 0;
		this.loginId = 0;
		this.email = "";
		this.lastName = "";
		this.lastNameRuby = "";
		this.firstName = "";
		this.firstNameRuby = "";
		this.sex = "";
		this.postalCode = "";
		this.prefecture = "";
		this.city = "";
		this.deleteFlg = "";
		this.registrationDate = "";
		this.updateDate = "";
		this.deleteDate = "";
		this.memberShipFlg = "";
	}

	//アクセサメソッドの定義
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getMemberShipFlg() {
		return memberShipFlg;
	}

	public void setMemberShipFlg(String memberShipFlg) {
		this.memberShipFlg = memberShipFlg;
	}

	public int getMemberShipId() {
		return userId;
	}

	public void setMemberShipId(int userId) {
		this.userId = userId;
	}

	public int getLoginId() {
		return loginId;
	}

	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLastNameRuby() {
		return lastNameRuby;
	}

	public void setLastNameRuby(String lastNameRuby) {
		this.lastNameRuby = lastNameRuby;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getFirstNameRuby() {
		return firstNameRuby;
	}

	public void setFirstNameRuby(String firstNameRuby) {
		this.firstNameRuby = firstNameRuby;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getPrefecture() {
		return prefecture;
	}

	public void setPrefecture(String prefecture) {
		this.prefecture = prefecture;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDeleteFlg() {
		return deleteFlg;
	}

	public void setDeleteFlg(String deleteFlg) {
		this.deleteFlg = deleteFlg;
	}

	public String getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getDeleteDate() {
		return deleteDate;
	}

	public void setDeleteDate(String deleteDate) {
		this.deleteDate = deleteDate;
	}

}
