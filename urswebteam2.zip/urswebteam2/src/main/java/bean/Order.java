package bean;

/*
 * 
 * 作成者:櫻井貴啓
 * 
 */


public class Order {

	//注文ID
	private int orderId;
	
	//ユーザーID
	private int userId;
	
	//詳細ID
	private int detailId;
	
	//商品購入数
	private int quantity;
	
	//注文日時
	private String orderDate;
	
	//合計金額
	private int totalAmount;
	
	//備考欄
	private String text;
	
	//入金日
	private String paymentDate;

	//発送日
	private String shippingDate;
	
	//コンストラクタ
	public Order() {
		this.orderId = 0;
		this.userId = 0;
		this.detailId = 0;
		this.quantity = 0;
		this.orderDate = "";
		this.totalAmount = 0;
		this.text = "";
		this.paymentDate = "";
		this.shippingDate = "";
	}	
	
	//各フィールド変数のゲッターセッターメソッド
	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
		
	public int getDetailId() {
		return detailId;
	}

	public void setDetailId(int detailId) {
		this.detailId = detailId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public int getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
		}

	public String getShippingDate() {
		return shippingDate;
	}

	public void setShippingDate(String shippingDate) {
		this.shippingDate = shippingDate;
	}
}
