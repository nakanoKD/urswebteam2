package util;

import java.text.NumberFormat;
import java.util.Locale;

public class MyFormat {
	
	public String moneyFormat(int price) {
		NumberFormat nf = NumberFormat.getCurrencyInstance(Locale.JAPAN);
	    nf.setGroupingUsed(true);
	    nf.setMaximumFractionDigits(0);
	    String priceNum = (nf.format(price));
		return priceNum;
	}

}
